
package testsphere;

public class TestSphere {
    public static void main(String[] args) {
        Sphere area[] = new Sphere[3];
        area[0] = new Sphere(101,"Red",4);
        area[1] = new Sphere(102,"Blue",3);
        area[2] = new Sphere(103,"Green",2);
        
        Sphere ob = new Sphere();
        
        System.out.println("Radius of Sphere Searched by ID 102 is : "+ob.getArea(area, 102));
        System.out.println("Radius of Sphere Searched by color Violet is : "+ob.getArea(area, "Violet"));
    }
}
