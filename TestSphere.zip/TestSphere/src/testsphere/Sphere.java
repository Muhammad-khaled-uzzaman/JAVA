package testsphere;

public class Sphere {

    private int sphereNo;
    private String color;
    private double radius;

    public Sphere() {

    }

    public Sphere(int sphereNo, String color, double radius) {
        this.sphereNo = sphereNo;
        this.color = color;
        this.radius = radius;
    }

    public double getArea(Sphere are[], int findByNum) {
        double area = 0.0;
        for (int i = 0; i < are.length; i++) {
            if (are[i].sphereNo == findByNum) {
                area = 4 * Math.PI * are[i].radius * are[i].radius;
            }
        }
        return area;
    }

    public double getArea(Sphere are[], String findByColor) {
        double area = 0.0;

        for (int i = 0; i < are.length; i++) {
            if (are[i].color.equals(findByColor)) {
                area = 4 * Math.PI * are[i].radius * are[i].radius;
            }
        }
        return area;
    }

}
