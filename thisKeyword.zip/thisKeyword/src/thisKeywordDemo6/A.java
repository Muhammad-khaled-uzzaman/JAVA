/*
Proving this keyword
Let's prove that this keyword refers to the current class instance variable. 
In this program, we are printing the reference variable and this, output of both variables are same.
*/
package thisKeywordDemo6;

public class A {
    
    void m()
    {
        System.out.println(this); //prints same reference ID  
    }
    
    public static void main(String[] args) {
        
        A ob = new A();
        System.out.println(ob);//prints the reference ID  
        
        ob.m();
    }
}
