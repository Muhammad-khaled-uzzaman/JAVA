
package thisKeywordDemo1;

public class Test {
    
    public static void main(String[] args) {
        
        Student s1 = new Student(441,"Daud","Java");
        Student s2 = new Student(442,"ankit","Java",4500);
        s1.display();
        s2.display();
    }
}
