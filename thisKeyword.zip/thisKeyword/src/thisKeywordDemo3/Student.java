/*
this: to pass as an argument in the method

The this keyword can also be passed as an argument in the method. 
It is mainly used in the event handling. Let's see the example:
*/
package thisKeywordDemo3;

public class Student {
    
    void m(Student s)
    {
        System.out.println("method is invoked");
    }
    
    void p()
    {
        m(this);
    }
    
    public static void main(String[] args) {
        
        Student s1 = new Student();
        s1.p();
        
    }
}
