
package thisKeywordDemo5;

public class Test {
    
    public static void main(String[] args) {
        
        new A().getA().msg();
    }
}
