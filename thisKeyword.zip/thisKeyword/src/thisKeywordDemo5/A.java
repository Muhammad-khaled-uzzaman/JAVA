/*
this keyword can be used to return current class instance
We can return this keyword as an statement from the method. In such case, 
return type of the method must be the class type (non-primitive). Let's see the example:
*/
package thisKeywordDemo5;

public class A {
    
    A getA()
    {
        return this;
    }
    
    void msg()
    {
        System.out.println("Hello java");
    }
}
