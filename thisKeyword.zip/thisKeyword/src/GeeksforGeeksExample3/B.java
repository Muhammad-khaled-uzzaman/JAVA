
package GeeksforGeeksExample3;
class B {
    
    int x = 5;
      
    // Default Contructor that create a object of A  
    // with passing this as an argument in the  
   // constructor 
    B(){
        A ob = new A(this);
    }
    
    void display(){
        System.out.println("Value of x in Class B  "+x);;
    }
    
    public static void main(String[] args) {
        B ob = new B();
       
    }
}
