/*
. Using ‘this’ keyword as an argument in the constructor call
*/
// Java code for using this as an argument in constructor 
// call 
// Class with object of Class B as its data member 
package GeeksforGeeksExample3;

class A {
    
    B ob;
    
    // Parameterized constructor with object of B  
    // as a parameter 
    A(B ob){
        this.ob = ob;
        
        ob.display();
    }
}
