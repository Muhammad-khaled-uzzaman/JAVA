
package thisKeywordDemo4;

public class B {
    
    A obj;
    
    B(A obj)
    {
        this.obj = obj;
    }
    void display()
    {
        System.out.println(obj.data);//using data member of A4 class  
    }
}
