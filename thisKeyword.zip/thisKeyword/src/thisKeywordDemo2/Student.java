/*

*/
package thisKeywordDemo2;

public class Student {
    
    int rollno;
    String name;
    String course;
    float fee;
    
    Student(int rollno,String name,String course)
    {
        this.rollno = rollno;
        this.name= name;
        this.course = course;
    }
     Student(int rollno,String name,String course,float fee)
    {
        this.fee = fee;
        //this(rollno,name,course);//reusing constructor  
        //error
        
    }
     
     void display()
     {
         System.out.println(rollno+" "+name+" "+course+" "+fee);
     }
     
     public static void main(String[] args) {
         Student s1 = new Student(441,"Daud","Java");
        Student s2 = new Student(442,"ankit","Java",4500);
        s1.display();
        s2.display();
    }
     //run == compile error
}
