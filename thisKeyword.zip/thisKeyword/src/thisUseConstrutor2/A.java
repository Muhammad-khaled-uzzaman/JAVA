/*
Calling parameterized constructor from default constructor:
*/
package thisUseConstrutor2;

public class A {
   
    A()
    {
        this(5);
        System.out.println("hello a");
    }
    A(int x)
    {
        System.out.println(x);
    }
    
    
}
