
package thisUseConstrutor2;

public class Test {
    
    public static void main(String[] args) {
        
        A a = new A();
    }
}
