/*
 example, parameters (formal arguments) and instance variables are same. 
So, we are using this keyword to distinguish local variable and instance variable
*/
package thisInstanceVariable;


public class Student {
    
    int rollno;
    String name;
    float fee;
    
    Student(int rollno,String name,float fee)
    {
        this.rollno = rollno;
        this.name = name;
        this.fee = fee;
    }
    
    void display()
    {
        System.out.println(rollno+" "+name+" "+fee);
    }
    
    public static void main(String[] args) {
        
        Student s1 = new Student(391,"Adnan",40000);
        Student s2 = new Student(392,"Khaled",45000);
        Student s3 = new Student(393,"Shuvo",50000);
        
        s1.display();
        s2.display();
        s3.display();
    }
}
