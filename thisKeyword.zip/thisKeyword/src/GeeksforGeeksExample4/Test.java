/*
Using ‘this’ keyword to invoke current class method
*/
// Java code for using this to invoke current  
// class method 
package GeeksforGeeksExample4;

public class Test {
    
    void display(){
        this.show();
        System.out.println("Inside display function");
    }
    
    void show(){
        System.out.println("Inside show funcion");
    }
    
    public static void main(String[] args) {
        Test t = new Test();
        t.display();
    }
}
