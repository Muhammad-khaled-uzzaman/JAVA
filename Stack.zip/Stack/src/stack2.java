
public class stack2 {

    private int arr[];
    private int top;
    private int capacity;

    stack2(int size) {
        arr = new int[size];
        capacity = size;
        top = -1;
    }

    public boolean isfull() {
        return top == capacity - 1;
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public int size() {
        return top + 1;
    }

    public void push(int x) {

        if (isfull()) {
            System.out.println("OverFlow\\nProgram Terminated\\n");
            System.exit(1);
        } else {
            System.out.println("Inserting " + x);
            arr[++top] = x;
        }
    }

    public int pop() {
        if (isEmpty()) {
            System.out.println("STACK EMPTY");
            System.exit(1);
        }
        return arr[top--];
    }

    public void printStack() {
        for (int i = 0; i <= top; i++) {
            System.out.println(arr[i]);

        }
    }

    public static void main(String[] args) {
        stack2 stack = new stack2(5);
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);

        int x = stack.pop();
        System.out.println("Popped : " + x);

        System.out.println("\\nAfter popping out");
        stack.printStack();
    }
}
