
package swing1;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class JScrollPaneDemo extends JFrame {
    private Container c;
    private JTextArea ta;
    private Font f;
    private JScrollPane scroll;
    JScrollPaneDemo()
    {
        initComponents();
    }
    public void initComponents()
    {
         c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.RED);
        
        f = new Font("Arial",Font.ITALIC,18);
        
        ta = new JTextArea(); 
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setFont(f);
       
        
        scroll = new JScrollPane(ta,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scroll.setBounds(50,50,300,200);
        c.add(scroll);
        
    }
    public static void main(String[] args) {
        JScrollPaneDemo frame = new JScrollPaneDemo();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,50,500,400);
        frame.setTitle("TextArea Demo");
    }
    
}
