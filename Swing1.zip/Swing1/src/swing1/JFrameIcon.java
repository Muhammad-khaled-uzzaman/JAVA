package swing1;

import java.awt.Color;
import java.awt.Container;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class JFrameIcon extends JFrame {
private ImageIcon icon;
private Container c;
    
    JFrameIcon(){
        initComponent();
    }
    public void initComponent(){
        
        c = this.getContentPane();
        c.setBackground(Color.yellow);
        icon = new ImageIcon(getClass().getResource("love.png"));
        this.setIconImage(icon.getImage());
    }
    public static void main(String[] args) {

        JFrameIcon frame = new JFrameIcon();

        frame.setVisible(true);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200, 50, 400, 300);

        frame.setTitle("Frame demo");
        frame.setResizable(false);
    }

}
