
package swing1;

import javax.swing.JOptionPane;

public class test3 {
    
    public static void main(String[] args) {
        
        int choice = JOptionPane.showConfirmDialog(null, "Do you want to quit this program?","Title",
                JOptionPane.YES_NO_OPTION);
        
        if (choice == JOptionPane.YES_OPTION) {
            System.exit(0);
            
        }
        else
        {
            System.out.println("You have clicked no option");
        }
    }
    
}
