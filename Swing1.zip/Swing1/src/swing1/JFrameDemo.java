
package swing1;

import javax.swing.JFrame;

public class JFrameDemo extends JFrame {
    
    JFrameDemo()
    {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(50,100,300,400);
        setTitle("This is a title");
    }
    public static void main(String[] args) {
        
        JFrameDemo frame = new JFrameDemo();
        
        frame.setVisible(true);
        
    }
    
}
