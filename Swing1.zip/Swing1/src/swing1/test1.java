
package swing1;

import javax.swing.JOptionPane;

public class test1 {
    public static void main(String[] args) {
        
        String name = JOptionPane.showInputDialog("Enter your name :");
        JOptionPane.showMessageDialog(null,name+ " welcome to swing");
    }
    
}
