
package swing1;

import javax.swing.JFrame;

public class test5 extends JFrame{
    
    public static void main(String[] args) {
        
        test5 frame = new test5();
        
        frame.setVisible(true);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //frame.setSize(400,300);
        //frame.setLocationRelativeTo(null);
        //frame.setLocation(200,50);
        
        frame.setBounds(200,50,400, 300);
        
        frame.setTitle("Frame demo");
        frame.setResizable(false);
        
        
    }
}
