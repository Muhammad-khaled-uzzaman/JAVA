
package swing1;

import javax.swing.JOptionPane;

public class test2 {
    
    public static void main(String[] args) {
        
        String f_name=JOptionPane.showInputDialog(null,"Enter your first name :","This is a title",
                JOptionPane.QUESTION_MESSAGE);
                
                String l_name=JOptionPane.showInputDialog("Enter your last name: ");
                
                String name =f_name+" "+l_name;
                
                JOptionPane.showMessageDialog(null,"Your full name : " +name);
                
    }
    
}
