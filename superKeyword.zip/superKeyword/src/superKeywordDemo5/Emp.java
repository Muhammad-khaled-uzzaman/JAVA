
package superKeywordDemo5;

public class Emp extends Person {
    
    float salary;
    
    Emp(int i,String n,float salary)
    {
        super(n,i);
        this.salary = salary;
    }
    
    void display()
    {
        System.out.println(id+" "+name+" "+salary);
    }
}
