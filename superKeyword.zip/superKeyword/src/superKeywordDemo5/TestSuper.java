
package superKeywordDemo5;

public class TestSuper {
    
    public static void main(String[] args) {
        
        Emp e1 = new Emp(1,"Muhammad Khaled",80000f);
        e1.display();
    }
}
