/*
Emp class inherits Person class so all the properties of Person will be 
inherited to Emp by default. To initialize all the property, 
we are using parent class constructor from child class. In such way, 
we are reusing the parent class constructor.
*/
package superKeywordDemo5;

public class Person {
    String name;
    int id;
    
    Person(String name,int id)
    {
        this.name = name;
        this.id = id;
    }
}
