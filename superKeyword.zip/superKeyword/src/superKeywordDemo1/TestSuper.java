
package superKeywordDemo1;

public class TestSuper {
    public static void main(String[] args) {
        
        Dog d = new Dog();
        d.printColor();
    }
}
