
package superKeywordDemo1;

public class Animal {
    
    String color = "White";
}
