package GeeksforGeeksExample3;

public class Person {

    Person() {
        
        System.out.println("Person class Constructor");
    }
}
