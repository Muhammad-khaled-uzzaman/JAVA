package GeeksforGeeksExample3;

public class Student extends Person {

    Student() {
        
        super();
        
        System.out.println("Student class Constructor");
    }
}
