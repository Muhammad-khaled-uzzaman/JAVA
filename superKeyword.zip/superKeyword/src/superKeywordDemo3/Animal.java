/*
The super keyword can also be used to invoke the parent class constructor.
Let's see a simple example:
*/
package superKeywordDemo3;

public class Animal {
    Animal()
    {
        System.out.println("animal is created");
    }
           
}
