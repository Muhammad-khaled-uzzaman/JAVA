
package superKeywordDemo3;

public class Dog extends Animal {
    
    Dog()
    {
        super();
        System.out.println("Dog is created");
    }
}
