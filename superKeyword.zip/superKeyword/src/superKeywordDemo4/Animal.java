//Another example of super keyword where super() is provided by the compiler implicitly.
package superKeywordDemo4;

public class Animal {
    
    Animal()
    {
        System.out.println("Animal is created");
    }
}
