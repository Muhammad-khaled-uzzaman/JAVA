

package superKeywordDemo4;

public class TestSuper {
    public static void main(String[] args) {
        
        Dog ob = new Dog();
    }
}
