
package superKeywordDemo4;

public class Dog extends Animal {
    
    Dog()
    {
        System.out.println("Dog is created");
    }
}
