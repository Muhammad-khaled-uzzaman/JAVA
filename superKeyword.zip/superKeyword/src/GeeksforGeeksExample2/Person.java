package GeeksforGeeksExample2;

public class Person {

    void message() {
        System.out.println("This is Person class");
    }
}
