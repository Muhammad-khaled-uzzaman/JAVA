package GeeksforGeeksExample2;

public class Test {

    public static void main(String[] args) {
        Student s = new Student();
        s.display();
    }
}
