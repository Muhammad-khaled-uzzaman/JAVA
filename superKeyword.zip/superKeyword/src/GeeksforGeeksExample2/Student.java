package GeeksforGeeksExample2;

public class Student extends Person {

    @Override
    void message() {
        System.out.println("This is student class");
    }

    void display() {

        message();

        super.message();
    }
}
