
package superKeywordDemo2;

public class TestSuper {
    public static void main(String[] args) {
        
        Dog ob = new Dog();
        ob.work();
    }
}
