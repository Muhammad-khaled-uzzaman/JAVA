
package superKeywordDemo2;

public class Dog extends Animal {
    
    @Override
    void eat()
    {
        System.out.println("eating bread..."); 
    }
    void bark()
    {
        System.out.println("barking...");
    }
    void work()
    {
       super.eat();
       eat();
       bark();
    }
}
