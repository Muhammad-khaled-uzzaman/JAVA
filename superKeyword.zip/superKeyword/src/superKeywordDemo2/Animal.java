
package superKeywordDemo2;

public class Animal {
    void eat()
    {
        System.out.println("eating..");
    }
}
