
package GeeksforGeeksexample1;

public class Vehicle {
    
    int maxSpeed = 120;
}
