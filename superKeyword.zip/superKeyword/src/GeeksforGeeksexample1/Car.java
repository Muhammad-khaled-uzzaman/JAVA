
package GeeksforGeeksexample1;

public class Car extends Vehicle  {
    
    int maxSpeed = 180;
    
    void display(){
        System.out.println("Maximum Speed: "+super.maxSpeed);
    }
    
}
