
package GeeksforGeeksexample1;

public class Test {
    
    public static void main(String[] args) {
        
       Car c = new Car();
       c.display();
        
        
    }
}
