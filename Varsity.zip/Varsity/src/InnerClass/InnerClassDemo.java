
package InnerClass;

public class InnerClassDemo {
    
    public static void main(String[] args) {
        Student s = new Student(18,1,4,102,"Khaled");
        System.out.println(s.toString());
    }
}
