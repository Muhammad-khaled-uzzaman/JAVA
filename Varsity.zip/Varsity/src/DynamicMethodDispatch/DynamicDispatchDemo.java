
package DynamicMethodDispatch;

public class DynamicDispatchDemo {
    public static void main(String args[]){
		Bank []banks= new Bank[02];
		banks[0] = new OneBank("One Bank Ltd", 0.07 );
		banks[1]= new BracBank("Brac bank Ltd", 0.065);
		
		System.out.println(Bank.whoHasHeightestInterest(banks));
	}
	
}
