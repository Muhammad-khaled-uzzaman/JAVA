
package DynamicMethodDispatch;

public class BracBank extends Bank {
    public BracBank(String bankName, double interestRate) {
		super(bankName, interestRate);
	}
}
