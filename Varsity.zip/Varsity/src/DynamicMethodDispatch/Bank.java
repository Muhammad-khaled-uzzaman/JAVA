
package DynamicMethodDispatch;

public class Bank {
    double interestRate;
	String bankName;
	
	public Bank(String bankName, double interestRate) {
		super();
		this.bankName = bankName;
		this.interestRate = interestRate;
	}
	
	static String whoHasHeightestInterest(Bank []banks){
		String bankName="";
		double heightInterestRate=Double.MIN_VALUE;  
		for(Bank b: banks){
			if(b.getInterestRate()>= heightInterestRate){
				heightInterestRate=b.getInterestRate();
				bankName=b.getBankName();
			}
		}
		
		return bankName;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
}



