
package DynamicMethodDispatch;

public class OneBank extends Bank {
    
	public OneBank(String bankName, double interestRate) {
		super(bankName, interestRate);
	}
}
