package abstractClass;

public class DynamicMehtodDispatchAbstractClass {

    public static void main(String[] args) {
        CseStudent cs1 = new CseStudent("Rahim", 240.5);
        ArchStudent as1 = new ArchStudent("Karim", 255.5);
        System.out.println(Student.compareStudent(cs1, as1));
        System.out.println(cs1.calculateCgpa());
        System.out.println(as1.calculateCgpa());
    }
}
