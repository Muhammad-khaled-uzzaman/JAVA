
package abstractClass;

public class ArchStudent extends Student {
    
     ArchStudent(String name,double totalCgpa){
        super(name,totalCgpa);
    }
    @Override
    double calculateCgpa(){
        return super.totalCPGA/152.5;
    }
}
