package abstractClass;

public class CseStudent extends Student {
    
    CseStudent(String name,double totalCgpa){
        super(name,totalCgpa);
    }
    @Override
    double calculateCgpa(){
        return super.totalCPGA/141.5;
    }
    
}
