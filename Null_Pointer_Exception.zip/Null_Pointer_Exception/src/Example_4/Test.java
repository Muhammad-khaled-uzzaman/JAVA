package Example_4;
import java.io.*; 
public class Test {

    public static void main(String[] args) {

        String s = "";
        try {
            getLength(s);
            System.out.println(s.length());
        } catch (IllegalArgumentException e) {
            System.out.println("IllegalArgumentException caught");
        }
        s = "muhammad Asif";

        try {
            getLength(s);
            System.out.println(s.length());
        } catch (IllegalArgumentException e) {
            System.out.println("IllegalArgumentException caught");
        }
        s = null;
        try {
            getLength(s);
            System.out.println(s.length());
        } catch (IllegalArgumentException e) {
            System.out.println("IllegalArgumentException caught");
            System.out.println(e.getMessage());
        }
        

    }

    public static int getLength(String s) {
        if (s == null) {
            throw new IllegalArgumentException("The argument cannot be null");
        }
        return s.length();
    }
}
