
package Example_1;

public class TestSingleton {
    
    public static void main(String[] args) {
        Singleton s = Singleton.getInstance();
        System.out.println(s.getID());
    }
}
