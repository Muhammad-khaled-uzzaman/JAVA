
package Example_3;

public class Test {
    
    public static void main(String[] args) {
        
        String str = null;
        
        // Checking if str is null using try catch.
        try{
            if("test".equals(str)){
                System.out.println("Same");
            }
            else{
                System.out.println("Not Same");
            }
        }catch(NullPointerException e){
            System.out.println("Caught NullPointerException");
        }
    }
}
