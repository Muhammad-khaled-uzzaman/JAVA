
package Example_2;

public class Test {
    
    public static void main(String[] args) {
        
        String str = null;
        
        try{
            if(str.equals("test")){
                System.out.println("same");
            }
            else{
                System.out.println("Not Same");
            }
        }catch(NullPointerException e){
            System.out.println("NullPointerException Caught");
        }
    }
}
