
package Example_5;

public class Test {
    
    public static void main(String[] args) {
        String str = null;
        String message =(str == null) ? "" : str.substring(0,5);
        System.out.println(message);
        
        str = "Geeksforgeeks"; 
        message = (str == null) ? "" : str.substring(0,5); 
        System.out.println(message); 
    }
}
