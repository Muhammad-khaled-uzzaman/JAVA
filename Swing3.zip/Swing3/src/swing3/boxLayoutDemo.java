
package swing3;

import java.awt.Color;
import java.awt.Container;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class boxLayoutDemo extends JFrame {
    private Container c;
    private JButton btn1,btn2,btn3,btn4,btn5;
    private BoxLayout box;
    boxLayoutDemo()
    {
        initComponents();
    }
    public void initComponents()
    {
        c = this.getContentPane();
        //BoxLayout(container ,BoxLayout.Y_AXIS)
        box = new BoxLayout(c,BoxLayout.X_AXIS);
        c.setLayout(box);
        c.setBackground(Color.yellow);
        
        btn1 = new JButton("1");
        btn2 = new JButton("2");
        btn3 = new JButton("3");
        btn4 = new JButton("4");
        btn5 = new JButton("5");
        
        c.add(btn1);
        c.add(Box.createHorizontalStrut(10));
        c.add(btn2);
        c.add(btn3);
        c.add(btn4);
        c.add(btn5);
          
    }
    public static void main(String[] args) {
        boxLayoutDemo frame = new boxLayoutDemo();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,500,500);
        frame.setTitle("Box Layout Demo ");
    }
    
}
