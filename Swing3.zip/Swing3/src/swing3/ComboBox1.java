
package swing3;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JComboBox;
import javax.swing.JFrame;

public class ComboBox1 extends JFrame {
     private Container c;
     private JComboBox cb;
     private String[] programLanguage = {"C","C++","Java","PHP","Python"};
    ComboBox1()
    {
        initComponents();
    }
    public void initComponents()
    {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(100,100,500,500);
        this.setTitle("ComboBox Demo");
        
         
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.MAGENTA);
        
        cb = new JComboBox(programLanguage);
        cb.setBounds(50,150,100,50);
        cb.setEditable(true);
        cb.setSelectedItem("PHP");
        cb.addItem("Fortran");
        //cb.removeItem("Java");
        cb.removeItemAt(2);
        c.add(cb);
        
        System.out.println("Total item = "+cb.getItemCount());
    }
    public static void main(String[] args) {
         ComboBox1 frame = new ComboBox1();
        frame.setVisible(true);
    }
}
