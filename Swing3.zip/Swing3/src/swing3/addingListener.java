
package swing3;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

public class addingListener extends JFrame implements ActionListener {
    private Container c;
    private JButton redButton,greenButton,blueButton;
    
    addingListener()
    {
         initComponents();
    }
    public void initComponents()
    {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(100,100,500,500);
        this.setTitle("Action Listener Demo");
        
         
        c = this.getContentPane();
        c.setLayout(null);
        
        redButton = new JButton("RED");
        redButton.setBounds(50,50,100,50);
        c.add(redButton);
        
        greenButton = new JButton("GREEN");
       greenButton.setBounds(50,110,100,50);
        c.add(greenButton);
        
        blueButton = new JButton("BLUE");
        blueButton.setBounds(50,170,100,50);
        c.add(blueButton);
        
        redButton.addActionListener(this);
        greenButton.addActionListener(this);
        blueButton.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==redButton)
        {
            c.setBackground(Color.RED);
        }
        else if(e.getSource()==greenButton)
        {
            c.setBackground(Color.GREEN);
        }
        else if(e.getSource()==blueButton)
        {
            c.setBackground(Color.BLUE);
        }
    }
    public static void main(String[] args) {
        addingListener frame = new addingListener();
        frame.setVisible(true);
    }
    
}
