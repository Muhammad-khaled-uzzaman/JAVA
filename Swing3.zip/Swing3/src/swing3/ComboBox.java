
package swing3;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JComboBox;
import javax.swing.JFrame;

public class ComboBox extends JFrame {
     private Container c;
     private JComboBox cb;
     private String[] programLanguage = {"C","C++","Java","PHP","Python"};   
     ComboBox()
    {
        initComponents();
    }
    public void initComponents()
    {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(100,100,500,500);
        this.setTitle("ComboBox Demo");
        
         
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.MAGENTA);
        
        cb = new JComboBox(programLanguage);
        cb.setBounds(50,150,100,50);
        cb.setEditable(true);
        c.add(cb);
    }
    public static void main(String[] args) {
         ComboBox frame = new ComboBox();
        frame.setVisible(true);
    }
    
}
