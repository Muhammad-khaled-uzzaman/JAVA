

package swing3;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class flowLayoutDemo extends JFrame {
    private Container c;
    private JButton buttons[];
    private FlowLayout fLayout;
    
    flowLayoutDemo()
    {
    initComponents();
    }
    public void initComponents()
    {
        c = this.getContentPane();
        fLayout = new FlowLayout(FlowLayout.LEFT);
        fLayout.setHgap(10);
        fLayout.setVgap(20);
        c.setLayout(fLayout);
        c.setBackground(Color.PINK);
        
        buttons = new JButton[9];
        
        for (int i = 0; i < 8; i++) {
            buttons[i] = new JButton(" "+(i+1));
            c.add(buttons[i]);
        }
        
    }
    public static void main(String[] args) {
        flowLayoutDemo frame = new flowLayoutDemo();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,350,300);
        frame.setTitle("Flow Layout Demo ");
    }
}
