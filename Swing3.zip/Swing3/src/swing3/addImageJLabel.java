
package swing3;

import java.awt.Color;
import java.awt.Container;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class addImageJLabel extends JFrame {
    private Container c;
    private JLabel label;
    private ImageIcon img;
    addImageJLabel()
    {
        initComponents();
    }
    public void initComponents()
    {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.white);
        
        img = new ImageIcon(getClass().getResource("appel.png"));
        
        label = new JLabel("Apple",img,JLabel.LEFT);
        label.setBounds(50,50,300,220);
        c.add(label);
    }
    
    public static void main(String[] args) {
        addImageJLabel frame = new addImageJLabel();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,400,400);
        frame.setTitle("Add Image JLabel ");
    }
    
}
