
package swing3;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JFrame;

public class windowDemo extends JFrame {
    private Container c;
    windowDemo()
    {
        initComponents();
    }
    public void initComponents()
    {
           this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(100,100,400,400);
        this.setTitle("Window Listener Demo");
        
         
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.PINK);
        
        this.addWindowListener(new WindowListener(){
               @Override
               public void windowOpened(WindowEvent we) {
                   
                   System.out.println("windowOpened");
               }

               @Override
               public void windowClosing(WindowEvent we) {
                   
                   System.out.println("windowClosing");
               }

               @Override
               public void windowClosed(WindowEvent we) {
                   
                   System.out.println("windowClosed");
               }

               @Override
               public void windowIconified(WindowEvent we) {
                   
                   System.out.println("windowIconified");
               }

               @Override
               public void windowDeiconified(WindowEvent we) {
                   
                   System.out.println("windowDeiconified");
               }

               @Override
               public void windowActivated(WindowEvent we) {
                   
                   System.out.println("windowActivated");
               }

               @Override
               public void windowDeactivated(WindowEvent we) {
                   
                   System.out.println("windowDeactivated");
               }
        
        
        });
    }
    public static void main(String[] args) {
        windowDemo frame = new windowDemo();
        frame.setVisible(true);
    }
    
}
