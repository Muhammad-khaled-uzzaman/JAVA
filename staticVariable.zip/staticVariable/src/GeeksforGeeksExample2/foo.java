/*
// Example to illustrate accessing the instance method . 
*/
package GeeksforGeeksExample2;
import java.io.*; 
public class foo {
    
    String name ="";
    
    public void geek(String name){
        
        this.name = name;
    }
}
