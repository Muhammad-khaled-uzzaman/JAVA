package GeeksforGeeksExample2;

public class GFG {

    public static void main(String[] args) {

        foo ob = new foo();
        ob.geek("GeeksforGeeks");
        
        System.out.println(ob.name);

    }
}
