
package staticVariableDemo;

public class B {
    
    int x =30; //non static
    
    public static void main(String[] args) {
        
        //System.out.println(x);
        //compile time error
    }
}
