
package staticVariableDemo;

public class A {
    
    static int x=30;
    
    public static void main(String[] args) {
        System.out.println(x);
    }
    
    
}
