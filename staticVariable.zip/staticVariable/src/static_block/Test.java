/*
// Java program to demonstrate use of static blocks
*/
package static_block;

public class Test {
    
    static int x = 10;
    static int y ;
    
    static{
        System.out.println("Static block initialized.");
        
        y = x*4;
    }
    public static void main(String[] args) {
        System.out.println("from main");
        System.out.println("Value of x : "+Test.x);
        System.out.println("Value of y : "+y);
    }
}
