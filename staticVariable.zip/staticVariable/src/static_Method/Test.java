/*
 can be accessed before instantiating a class 
 */
package static_Method;

public class Test {

    static void m1() {
        System.out.println("from m1");
    }
    public static void main(String[] args) {
        m1();
    }
}
