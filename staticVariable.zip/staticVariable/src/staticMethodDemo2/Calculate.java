/*
Another example of a static method that performs a normal calculation
*/
package staticMethodDemo2;
//Java Program to get the cube of a given number using the static method  
public class Calculate {
    
    static int cube(int x)
    {
        return x*x*x;
    }
    
    public static void main(String[] args) {
        
        int result = Calculate.cube(5);
        System.out.println(result);
        
    }
}
