/*
// java program to demonstrate restriction on static methods 
 */
package static_variable;

public class Test {

    String name;
    int rollNo;

    static String cllgName;

    static int counter = 0;

    public Test(String name) {
        this.name = name;
        this.rollNo = setRollNo();

    }

    // getting unique rollNo 
    // through static variable(counter) 
    static int setRollNo() {
        counter++;
        return counter;
    }

    static void setCllg(String name) {

        cllgName = name;
    }

    void getStudentInfo() {
        System.out.println("name : " + this.name);
        System.out.println("rollNo : " + this.rollNo);
        System.out.println("cllgName : " + cllgName);

    }
}
