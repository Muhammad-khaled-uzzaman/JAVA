
package static_variable;

public class Main {
    
    public static void main(String[] args) {
        Test.setCllg("Aust");
        Test t1 = new Test("Rima");
        Test t2 = new Test("Pinky");
        
        t1.getStudentInfo();
        t2.getStudentInfo();
    }
}
