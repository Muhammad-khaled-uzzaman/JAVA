
package GeeksforGeeksExample1;

public class B extends A {
    
    static void fun(){
        System.out.println("B.fun()");
    }
}
