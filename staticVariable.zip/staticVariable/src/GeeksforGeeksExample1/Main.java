
package GeeksforGeeksExample1;

public class Main {
    
    public static void main(String[] args) {
        A a = new B();
        a.fun();     //// prints A.fun() 
        
    }
}
