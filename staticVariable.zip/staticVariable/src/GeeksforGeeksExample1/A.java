/*
Shadowing (or conceals) of static functions in Java
*/
package GeeksforGeeksExample1;

public class A {
    
    static void fun(){
        System.out.println("A.fun()");
    }
}
