/*
Example of static variable
*/
package staticDemo1;

public class Student {
    
    int rollno; //instance variable
    String name;
    static String college = "DIC";//static variable
    
    Student(int r,String n)
    {
        rollno = r;
        name = n;
    }
    
    void display()
    {
        System.out.println(rollno+" "+name+" "+college);
    }
    
    public static void main(String[] args) {
        
        Student s1 = new Student(101,"Mamun");
        Student s2 = new Student(102,"Masum");
        
        s1.display();
        s2.display();
    }
}
