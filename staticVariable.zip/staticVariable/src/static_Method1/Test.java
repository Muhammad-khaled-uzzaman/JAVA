/*
// java program to demonstrate restriction on static methods 
 */
package static_Method1;

public class Test {

    static int a = 10;

    int b = 20;

    static void m1() {
        a = 20;
        System.out.println("from m1");
        // Cannot make a static reference to the non-static field b 
        // b = 5;// compilation error 

        // Cannot make a static reference to the  
        // non-static method m2() from the type Te
        //m2();  // compilation error 
        m3();
        
        System.out.println(a);

        //  Cannot use super in a static context 
        // System.out.println(super.a); // compiler error  
    }

    void m2() {
        System.out.println("from m2");
    }

    static void m3() {
        System.out.println("from m3");
    }
    
    public static void main(String[] args) {
        m1();
    }
}
