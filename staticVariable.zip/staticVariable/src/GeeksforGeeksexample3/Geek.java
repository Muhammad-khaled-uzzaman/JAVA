/*
// Example to illustrate Accessing the Static method(s) of the class. 
*/
package GeeksforGeeksexample3;

public class Geek {
     
    public static String geekName ="";
    
    public static void geek(String name){
        geekName = name;
    }
}
