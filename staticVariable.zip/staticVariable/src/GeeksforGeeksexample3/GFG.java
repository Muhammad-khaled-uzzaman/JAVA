
package GeeksforGeeksexample3;

public class GFG {
    
    public static void main(String[] args) {
        
        // Accessing the static method geek() and  
        // field by class name itself. 
        Geek.geek("Muammad Khaled");
        System.out.println(Geek.geekName);
        
        // Accessing the static method geek() by using Object's reference.
        Geek ob = new Geek();
        ob.geek("Abul");
        
        System.out.println(ob.geekName);
    }
}
