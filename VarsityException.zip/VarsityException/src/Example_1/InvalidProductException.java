package Example_1;

public class InvalidProductException extends Exception {

    public InvalidProductException(String s) {
        super(s);
    }
}
