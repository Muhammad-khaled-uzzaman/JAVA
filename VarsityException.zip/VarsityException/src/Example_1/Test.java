package Example_1;

public class Test {

    void productCheck(int weight) throws InvalidProductException {
        if (weight < 100) {
            throw new InvalidProductException("Product Invalid");
        }
    }

    public static void main(String args[]) {
        Test obj = new Test();
        try {
            obj.productCheck(60);
        } catch (InvalidProductException ex) {
            System.out.println("Caught the exception");
            System.out.println(ex.getMessage());
        }
    }
}
