package varsityexception;

public class GmailException extends Exception {

    String emailAdd;

    public GmailException(String emailAdd) {
        this.emailAdd = emailAdd;
    }

    @Override
    public String toString() {
        return "You have given " + emailAdd + " as an email address , but you have to provide a gmail";
    }
}
