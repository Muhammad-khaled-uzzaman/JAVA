package Example_2;

public class MyOwnException extends Exception {

    public MyOwnException(String msg) {
        super(msg);
    }
}
