package interfa;

public interface SensonInterfaceForMobile {

    void sendGPSPosition(SensonInterfaceForMobile s);

    void receiveGPSPosition(int position);

    int getGPSPosition();

    int getVelocity();
}
