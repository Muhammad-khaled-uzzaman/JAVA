
package interfa;

public class IPhone extends Mobile implements SensonInterfaceForMobile {
    
    public IPhone(String model) {
		super(model);
	}
	
    @Override
	public int getGPSPosition() {
		return (int)(Math.random()*300);
	}
	
    @Override
	public int getVelocity() {
		return (int)(Math.random()*70);
	}
	
    @Override
	public void sendGPSPosition( SensonInterfaceForMobile s) {
		int currentGPSPositon = getGPSPosition();
		System.out.println("sending postion from IPhone: "+currentGPSPositon);
		s.receiveGPSPosition(currentGPSPositon);
		
	}
	
    @Override

    public void receiveGPSPosition(int position) {
		System.out.println("receiving GPS position to IPhone: "+position);
	}
	
    @Override
	public void sendingMessage(String message, Mobile m) {
		System.out.println("seding meassge: from IPhone: "+message);
		m.receivingMessage(message);
	}
	
    @Override
	void receivingMessage(String message) {
		System.out.println("Receiving message to IPhone: "+message);
	}
}
