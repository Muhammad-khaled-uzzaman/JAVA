
package interfa;

public class WaltonMobile extends Mobile {
    
    WaltonMobile(String model) {
		super(model);
	}
    @Override
	void sendingMessage(String message, Mobile m) {
		System.out.println("seding meassge from Walton: "+message);
		m.receivingMessage(message);
	}
	
    @Override
	void receivingMessage(String message) {
		System.out.println("Receiving message from Walton: "+message);
	}
}
