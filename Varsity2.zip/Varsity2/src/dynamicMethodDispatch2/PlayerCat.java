package dynamicMethodDispatch2;

public class PlayerCat extends Player implements Charecter  {

    PlayerCat(String name) {
        super(name);
    }

    @Override
    public String doMove() {
        return "A cat is moving";
    }

    @Override
    public String doJump() {
        return "A cat is jumping";
    }
    
    @Override
    public String getName(){
        return name;
    }

    @Override
    public void doAttack(Player a) {
        System.out.println(a.doMove());
        System.out.println(this.doMove());

        System.out.println(a.doJump());
        System.out.println(this.doJump());

        if (Math.random() > 0.5) {
            System.out.println(this.getName() + " is wining");
        } else {
            System.out.println(a.getName() + " is wining");
        }

    }
}
