package dynamicMethodDispatch2;

public interface Charecter {

    String doMove();

    String doJump();

    void doAttack(Player a);
}
