/*
Thread safe means that a method or class instance can be used by multiple 
threads at the same time without any problem.
 */
package volatile_keyword;

public class Volatile_keyword {

    // volatile keyword here makes sure that
    // the changes made in one thread are 
    // immediately reflect in other thread
    static volatile int a = 5;

}
