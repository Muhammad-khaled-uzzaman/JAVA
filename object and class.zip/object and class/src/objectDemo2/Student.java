/*
In real time development, we create classes and use it from another class.
It is a better approach than previous one. Let's see a simple example,
where we are having main() method in another class.
*/
package objectDemo2;
//Java Program to demonstrate having the main method in   
//another class  
//Creating Student class.  
public class Student {
    
    String name;
    int id;
}
