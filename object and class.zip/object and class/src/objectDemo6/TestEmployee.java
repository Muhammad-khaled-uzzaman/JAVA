
package objectDemo6;

public class TestEmployee {
    
    public static void main(String[] args) {
        
        Employee e1 = new Employee();
        Employee e2 = new Employee();
        Employee e3 = new Employee();
        
        e1.insert(101, "Mimi", 45000f);
        e2.insert(102, "Khaled", 80000f);
        e3.insert(103, "Mehedi", 40000f);
        
        e1.display();
        e2.display();
        e3.display();
        
    }
}
