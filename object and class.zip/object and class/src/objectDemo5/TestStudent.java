
package objectDemo5;

public class TestStudent {
    
    public static void main(String[] args) {
        
        Student s1 = new Student();
        Student s2 = new Student();
        s1.insertRecord(101, "Muhsin");
        s2.insertRecord(102, "Khaled");
        s1.displayInformation();
        s2.displayInformation();
    }
}
