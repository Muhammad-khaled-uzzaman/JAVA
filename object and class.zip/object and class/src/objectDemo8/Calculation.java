
package objectDemo8;

public class Calculation {
    
    int fact = 1;
    
    void fact(int n)
    {
        for (int i = 1; i <=n; i++) {
            fact = fact*i;
        }
        System.out.println("factorial is = "+fact);
    }
    
    public static void main(String[] args) {
        
        new Calculation().fact(5);;//calling method with anonymous object
    }
}
