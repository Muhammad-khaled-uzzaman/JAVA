/*
We can also create multiple objects and store information in it through reference variable.
*/
package objectDemo4;

public class Student {
    
    int id;
    String name;
}
