/*
In this example, we have created a Student class which has two data members id and name.
We are creating the object of the Student class by new keyword and printing the object's value.
*/
package objectDemo1;
//Java Program to illustrate how to define a class and fields  
//Defining a Student class.  
public class Student {
    //defining fields  
    String name; //field or data member or instance variable  
    int id;
    //creating main method inside the Student class  
    public static void main(String[] args) {
          //Creating an object or instance  
        Student s = new Student();//creating an object of Student  
        //Printing values of the object  
        System.out.println(s.name);//accessing member through reference variable  
        System.out.println(s.id);
    }
    
}
