
package objectDemo3;

public class TestStudent {
    
    public static void main(String[] args) {
        
        Student s = new Student();
        //reference variable
        s.id = 102;
        s.name = "Muhammad Khaleduzzaman";
        
        System.out.println(s.id+" "+s.name);
    }
}
