/*
Let's see a simple example where we are going to initialize 
the object through a reference variable.
*/
package objectDemo3;

public class Student {
    
    int id;
    String name;
}
