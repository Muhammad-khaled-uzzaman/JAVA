
package objectDemo7;

public class TestRectangle {
    
    public static void main(String[] args) {
        
        Rectangle r1 = new Rectangle(5,5);
        Rectangle r2 = new Rectangle(7,5);
        
        r1.calculateArea();
        r2.calculateArea();
        
        
    }
}
