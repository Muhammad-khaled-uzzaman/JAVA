/*
There is given another example that maintains the records of Rectangle class.
*/
package objectDemo7;

public class Rectangle {
    
    int length;
    int width;
    
   Rectangle(int l,int w)
   {
       length = l;
       width = w;
   }
    
    void calculateArea()
    {
        System.out.println(length*width);
    }
}
