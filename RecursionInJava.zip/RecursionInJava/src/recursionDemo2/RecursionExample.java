/*
Java Recursion Example 2: Finite times
 */
package recursionDemo2;

public class RecursionExample {

    static int count = 0;

    static void p() {
        count++;
        if (count <= 5) {
            System.out.println("hello " + count);

            p();
        }

    }

    public static void main(String[] args) {

        p();
    }
}
