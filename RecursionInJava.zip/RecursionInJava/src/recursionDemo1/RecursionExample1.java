/*
Java Recursion Example 1: Infinite times
*/
package recursionDemo1;

public class RecursionExample1 {
    
    static void p()
    {
        System.out.println("hello");
        p();
    }
    
    public static void main(String[] args) {
        
        p();
    }
}
