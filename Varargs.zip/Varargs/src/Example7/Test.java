
package Example7;

public class Test {
    static void fun(int a,String ...q){
        System.out.println("A : "+a);
        System.out.println("Number of arguments : "+q.length);
        for(String str : q){
            System.out.print(str+" ");
        }
        System.out.println();
    }
    public static void main(String[] args) {
        fun(5,"Pinky","Masum","Mehedi");
        Test.fun(5,args);
        fun(10,"");
    }
}
