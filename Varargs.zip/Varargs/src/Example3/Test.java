
package Example3;

public class Test {
    public static void fun(int a,int b,int ...c){
        System.out.println("Number of arguments : "+c.length);
        System.out.println("A : "+a);
        System.out.println("B : "+b);
        for(int i : c){
            System.out.print(i+" ");
        }
        System.out.println();
    }
    public static void main(String[] args) {
        fun(10,20,1,2,3,4,5);
        fun(5,6);
    }
}
