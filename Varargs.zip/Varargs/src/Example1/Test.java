/*
Variable Arguments (Varargs) in Java
*/
package Example1;

public class Test {
    
    public static void fun(int ...a){
        System.out.println("Number of arguments: "+a.length);
        
        for(int i : a){
            System.out.print(i+" ");
        }
        System.out.println();
    }
    public static void main(String[] args) {
        Test.fun(100);
        fun(1,2,3,4);
        Test t = new Test();
        t.fun();
    }
}
