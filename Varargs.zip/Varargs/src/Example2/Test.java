/*
n this case, the first two arguments are matched with the first 
two parameters and the remaining arguments belong to c
*/
//vararg appear before normal argument
package Example2;

public class Test {
    static void fun(String str,int ...a){
        System.out.println("String : "+str);
        System.out.println("Number of arguments is: "+a.length);
        
        for(int i : a){
            System.out.print(i+" ");
        }
        System.out.println();
    }
    public static void main(String[] args) {
        Test.fun("Muhammad", 102);
        fun("Khaled",10,50,20);
        fun("Muntacir");
    }
}
