/*
Compile time error as vararg appear before normal argumen
 */
package Example6;

public class Test {

    /* static void fun(int ...a,String q) */
    {

        // Compile time error as vararg appear
        // before normal argument
        System.out.println("");
    }

    public static void main(String[] args) {

    }
}
