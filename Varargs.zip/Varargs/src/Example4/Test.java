
package Example4;

public class Test {
    
    public static void fun(int a,float b,double ...c){
        System.out.println("A : "+a);
        System.out.println("B : "+b);
        System.out.println("Number of arguments : "+c.length);
        for(double i : c){
            System.out.print(i+" ");
        }
        System.out.println();
    }
    public static void main(String[] args) {
        Test.fun(5, 10.2f, 10.22,10.23,20.22);
        fun(10,10.5f);
    }
}
