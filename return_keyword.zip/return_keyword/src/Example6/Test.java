package Example6;

public class Test {

    void display(double i) {
        if (i < 0) {
            System.out.println(i);
            return;
        } else {
            i++;
        }
    }

    public static void main(String[] args) {

        new Test().display(-1);
        System.out.println("In main");
    }
}
