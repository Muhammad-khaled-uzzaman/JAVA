package Singleton_Classes;

public class Main {

    public static void main(String[] args) {

        Test t1 = Test.getInstance();
        Test t2 = Test.getInstance();

        t1.x = t1.x + 10;
        System.out.println("Value of t1.x = " + t1.x);
        System.out.println("Value of t2.x = " + t2.x);
    }
}
