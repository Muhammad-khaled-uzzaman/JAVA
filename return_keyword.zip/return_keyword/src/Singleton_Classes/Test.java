package Singleton_Classes;

import java.io.*;

public class Test {

    static Test instance = null;
     int x =10;

    // private constructor can't be accessed outside the class 
    private Test() {
      
    }
    // Factory method to provide the users with instances 

    static public Test getInstance() {
        if (instance == null) {
            instance = new Test();
        }
        return instance;
    }
}
