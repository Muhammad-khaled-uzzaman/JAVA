
package Example1;

public class A {
    
    double m(double a,double b){
        double sum = 0;
        sum = (a+b)/2;
        return sum;
    }
    public static void main(String[] args) {
        A a = new A();
        System.out.println(a.m(5.5, 6.5));
        System.out.println(new A().m(7.5, 4.5));
        
    }
}
