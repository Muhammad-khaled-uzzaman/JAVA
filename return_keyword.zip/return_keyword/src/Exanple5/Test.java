
package Exanple5;

public class Test {
    
    void m(double j){
        return;
        
         // here get compile error since can't 
        // write any statement after return keyword 
        //++j;
    }
    public static void main(String[] args) {
        
        new Test().m(5);
        System.out.println("in main");
    }
}
