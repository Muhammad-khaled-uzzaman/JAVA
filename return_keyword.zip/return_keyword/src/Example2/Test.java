
package Example2;

public class Test {
    
    void m(int a,int b){
        int sum = 0;
        sum =(a+b)/10;
        System.out.println(sum);
    }
    
    public static void main(String[] args) {
       new Test().m(10, 5);
    }
}
