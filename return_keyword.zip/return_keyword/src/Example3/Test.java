package Example3;

public class Test {

    void m(double j) {
        if (j < 9) {

            // return statement below(only using  
            // return statement and not returning  
            // anything): 
            // control exits the method if this  
            // condition(i.e, j<9) is true. 
            return;
        }
        j++;
        System.out.println(j);
    }

    public static void main(String[] args) {

        new Test().m(5.5);
        System.out.println("In main");
    }
}
