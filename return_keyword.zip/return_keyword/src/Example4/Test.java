
package Example4;

public class Test {
    
    void m(double j){
        if(j<9){
            return;
        }
        else{
            j++;
        }
    }
    public static void main(String[] args) {
        
        new Test().m(5.6);
        System.out.println("In main");
    }
}
