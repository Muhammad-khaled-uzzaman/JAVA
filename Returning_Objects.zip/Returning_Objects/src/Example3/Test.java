
package Example3;

public class Test {
    
    int a;
    Test(int i){
        a = i;
    }
   
    // This method returns an object 
    Test incrByTen(){
        Test temp = new Test(a+10);
        return temp;
    }
}
