
package Example3;

public class Main {
    public static void main(String[] args) {
        Test t1 = new Test(3);
        Test t2 ;
        
        t2 = t1.incrByTen();
        
        System.out.println("t1.a = "+t1.a);
        System.out.println("t2 = "+t2.a);
    }
}
