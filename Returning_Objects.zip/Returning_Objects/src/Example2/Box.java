/*
Defining a constructor that takes an object of its class as a parameter
*/
package Example2;

public class Box {
    double width, height,depth;
    // Notice this constructor. It takes an 
    // object of type Box. This constructor use 
    // one object to initialize another 
    Box(Box ob){
        width = ob.width;
        height = ob.height;
        depth = ob.depth;
    }
    Box(double w,double h,double d){
        width = w;
        height = h;
        depth = d;
    }
     double volume(){
        return width*height*depth;
    }
}
