
package Example2;

public class Test {
    public static void main(String[] args) {
        // creating a box with all dimensions specified
        Box mybox = new Box(5,6,7);
        //  creating a copy of mybox 
        Box myclone = new Box(mybox);
        
        double vol;
        
        vol = mybox.volume();
        System.out.println("Volume of mybox is : "+vol);
        
        // get volume of myclone 
        vol = mybox.volume();
        System.out.println("Volume of myclone is : "+vol);
    }
}
