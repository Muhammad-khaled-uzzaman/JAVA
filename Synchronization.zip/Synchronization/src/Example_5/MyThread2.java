package Example_5;

public class MyThread2 extends Thread {

    @Override
    public void run() {
        Table.printTable(10);
    }
}
