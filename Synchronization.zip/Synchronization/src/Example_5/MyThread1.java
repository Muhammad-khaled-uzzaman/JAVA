
package Example_5;

public class MyThread1 extends Thread {
    
    @Override
    public void run(){
        Table.printTable(1);
    }
}
