
package Example_5;

public class MyThread3 extends Thread {
    
     @Override
    public void run(){
        Table.printTable(100);
    }
}
