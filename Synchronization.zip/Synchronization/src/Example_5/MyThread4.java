package Example_5;

public class MyThread4 extends Thread {

    @Override
    public void run() {
        Table.printTable(1000);
    }
}
