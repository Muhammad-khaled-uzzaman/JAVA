package Example_12;

public class Test {

    public static void main(String[] args) {
        Thread t1 = new Thread(new MyClass(), "Thread1");
        Thread t2 = new Thread(new MyClass(), "Thread2");
        Thread t3 = new Thread(new MyClass(), "Thread3");

        t1.start();
        t2.start();
        t3.start();
    }
}
