
package Example_4;

public class Test {
    
    public static void main(String[] args) {
        
        final Table ob = new Table();
        Thread t1 = new Thread(){
            @Override
            public void run(){
                ob.printTable(5);
            }
        };
        
        Thread t2 = new Thread(){
            @Override
            public void run(){
                ob.printTable(100);
            }
        };
        
        t1.start();
        t2.start();
    }
}
