
package Example_11;

public class Test {
    public static void main(String[] args) {
        Count cnt = new Count();
        try {
            while (cnt.t.isAlive()) {
                System.out.println("Main thread will be alive till the child thread islive");
                Thread.sleep(1500);
            }
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted");
        }
        System.out.println("Main thread's run is over");

    }
}
