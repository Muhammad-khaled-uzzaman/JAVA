
package Example_10;

public class Test implements Runnable {
    
    @Override
    public void run(){
        System.out.println("My thread is running state");
    }
    
    public static void main(String[] args) {
        Test t = new Test();
        Thread t1 = new Thread(t);
        t1.start();
    }
}
