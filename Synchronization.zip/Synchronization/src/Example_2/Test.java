package Example_2;

public class Test {

    public static void main(String[] args) {
        Table obj = new Table();//only one object  
        MyThread1 my1 = new MyThread1(obj);
        Thread t1 = new Thread(my1);

        MyThread2 my2 = new MyThread2(obj);
        Thread t2 = new Thread(my2);

        MyThread3 my3 = new MyThread3(obj);
        Thread t3 = new Thread(my3);
        t1.start();
        t2.start();
        t3.start();
    }
}
