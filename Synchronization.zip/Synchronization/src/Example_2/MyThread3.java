package Example_2;

public class MyThread3 extends Thread {

    Table t;

    MyThread3(Table t) {
        this.t = t;
    }

    @Override
    public void run() {
        t.printTable(15);
    }
}
