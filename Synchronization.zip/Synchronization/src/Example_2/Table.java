package Example_2;

public class Table {

    synchronized void printTable(int i) {
        for (int j = 1; j <= 5; j++) {
            System.out.println(i * j);

            try {
                Thread.sleep(400);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }

    }
}
