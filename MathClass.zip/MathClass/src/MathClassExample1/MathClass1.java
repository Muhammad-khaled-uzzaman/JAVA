package MathClassExample1;

public class MathClass1 {

    public static void main(String[] args) {
        double x = 28;
        double y = 4;

        System.out.println("Maximum number of x and y is : " + Math.max(x, y));

        System.out.println("Squqre root of y is : " + Math.sqrt(y));

        System.out.println("Power of x andv y is : " + Math.pow(x, y));

        System.out.println("Logarithm of  is : " + Math.log(x));
        System.out.println("Logarithm of  is : " + Math.log(y));

        // return the logarithm of given value when base is 10    
        System.out.println("log10 of x is: " + Math.log10(x));
        System.out.println("log10 of y is: " + Math.log10(y));

        // return the log of x + 1  
        System.out.println("log1p of x is : " + Math.log1p(x));

        // return a power of 2    
        System.out.println("exp of a is: " + Math.exp(x));
        
        // return (a power of 2)-1  
        System.out.println("expm1 of a is: " +Math.expm1(x));
    }
}
