/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package readerwriterassignment;

/**
 *
 * @author pc
 */
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
public class ReaderWriterAssignment {

     int bufferSize = 10;
 
    private final Queue<Integer> buffer = new LinkedList<>();

    
    
    static Semaphore readLock = new Semaphore(1);
    static Semaphore writeLock = new Semaphore(1);
    static int readCount = 0;

    Random rand = new Random();
  
    Scanner sc = new Scanner(System.in);
    
     class Read implements Runnable {
        @Override
        public void run() {
            try { 
               
                int reading_item = rand.nextInt(1000);
               
               
                buffer.add(reading_item);
                
                
               
                readLock.acquire();
                readCount++;
                if (readCount == 1) {
                    writeLock.acquire();
                }
                readLock.release();

                //Reading section
                System.out.println("Reader "+Thread.currentThread().getName() + " Reading " + reading_item );
                Thread.sleep(500);
                System.out.println("Reader "+Thread.currentThread().getName() + " Leaves");
             

                
                readLock.acquire();
                readCount--;
                if(readCount == 0) {
                    writeLock.release();
                }
                readLock.release();
                 Thread.sleep(2500);
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
        }
    }

     class Write implements Runnable {
        @Override
        public void run() {
            try {
                
                writeLock.acquire();
                Thread.sleep(400);
                int writing_item = buffer.remove();
                 
                 
                System.out.println("Writer "+Thread.currentThread().getName() + " Writes in the system " + writing_item );
                Thread.sleep(200);
                System.out.println("Writer  "+Thread.currentThread().getName() + " Leaves the system");
                writeLock.release();
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public static void main(String[] args) throws Exception {
        
        
       ReaderWriterAssignment pc = new ReaderWriterAssignment();

      
        Read read = pc.new Read();
        Write write = pc.new Write();
    
       
        Thread thread1 = new Thread(read);
        thread1.setName("1");
        Thread thread2 = new Thread(read);
        thread2.setName("2");
        Thread thread3 = new Thread(write);
        thread3.setName("3");
        Thread thread4 = new Thread(read);
        thread4.setName("4");
        Thread thread5 = new Thread(write);
        thread5.setName("5");
        thread1.start();
        thread3.start();
        thread2.start();
        thread4.start();
        thread5.start();
    }
}
