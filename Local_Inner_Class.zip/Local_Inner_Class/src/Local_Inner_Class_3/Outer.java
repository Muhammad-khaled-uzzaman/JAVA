/*
Demonstrating Erroneous codes for Inner class
*/
// Java code to demonstrate that inner 
// classes cannot be declared as static 
package Local_Inner_Class_3;

public class Outer {
    
    private int getValue(int data){
         class Inner{ // classes cannot be declared as static 
            private int getData(){
                System.out.println("Inside inner class");
                if(data<5){
                    return 5;
                }
                else{
                    return 15;
                }
            }
        }
         Inner inner = new Inner();
         return inner.getData();
    }
    public static void main(String[] args) {
        
        Outer outer = new Outer();
        System.out.println(outer.getValue(10));
    }
}
