
package Anonymous_inner_classes_2;

public interface Hello {
    
    void show();
}
