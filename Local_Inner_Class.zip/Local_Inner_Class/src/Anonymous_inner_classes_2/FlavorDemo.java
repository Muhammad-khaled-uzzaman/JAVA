/*
 As implementer of the specified interface
*/
package Anonymous_inner_classes_2;

public class FlavorDemo {
    
    // An anonymous class that implements Hello interface 
    
    static Hello h = new Hello(){
        @Override
        public void show(){
            System.out.println("i am in anonymous class");
        }
    };
    public static void main(String[] args) {
        h.show();
    }
}
