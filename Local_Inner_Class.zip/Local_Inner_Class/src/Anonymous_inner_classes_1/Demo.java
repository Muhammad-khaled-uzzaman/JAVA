/*
Anonymous inner classes
Anonymous inner classes are declared without any name at all. 
They are created in two ways.
a) As subclass of specified type
*/
package Anonymous_inner_classes_1;

public class Demo {
    
    void show(){
        System.out.println("i am in show method of super class");
    }
}
