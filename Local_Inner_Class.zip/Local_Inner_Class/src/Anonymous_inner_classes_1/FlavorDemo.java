
package Anonymous_inner_classes_1;

public class FlavorDemo {
    
    //  An anonymous class with Demo as base class 
     static Demo d = new Demo(){
        @Override
        void show(){
            super.show();
            System.out.println("i am in FlavorDemo class");
        }
    };
    public static void main(String[] args) {
      
       d.show();
    }
}
