package testtaxi;

public class Taxi {

    private String destination;
    private double distance;
    private double fairPerKm;

    Taxi() {
        destination = null;
        distance = -1.0;
        fairPerKm = 1.0;

    }

    Taxi(String destination, double distance, double fairPerKm) {
        this.destination = destination;
        this.distance = distance;
        this.fairPerKm = fairPerKm;

    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public double getFairPerKm() {
        return fairPerKm;
    }

    public void setFairPerKm(double fairPerKm) {
        this.fairPerKm = fairPerKm;
    }
    
    public double computeTotalFair() {
        double totalFair = distance*fairPerKm;
        return (totalFair -(totalFair*0.2));
    }
    
    public String compareFair(Taxi ob){
        String comp=null;
        if (computeTotalFair()==ob.computeTotalFair()) {
            
            comp = "same";
            return comp;
        }
        
        else if (computeTotalFair()>ob.computeTotalFair()) {
            
            comp = "more";
            return comp;
        }
        
        else  {
            comp = "less";
            return comp;
        }
    }  
}
