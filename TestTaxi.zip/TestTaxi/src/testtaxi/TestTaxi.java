
package testtaxi;

public class TestTaxi {
    public static void main(String[] args) {
        Taxi taxi1 = new Taxi("wari",7,50);
        Taxi taxi2 = new Taxi("Mirpur",5,45);
        
        
         System.out.println("Total fair to " + taxi1.getDestination() +" is " +
                                               taxi1.computeTotalFair());
        
        System.out.println("Total fair to " + taxi2.getDestination() +" is " +
                                               taxi2.computeTotalFair());
        
        System.out.println("Fair of " + taxi1.getDestination() +" is " +
                           taxi1.compareFair(taxi2) + " than " +taxi2.getDestination());
    
        taxi1.setFairPerKm(20);
        
        System.out.println("Total fair to " +taxi1.getDestination() +" is " +
                                               taxi1.computeTotalFair());
        
        System.out.println("Fair of " + taxi1.getDestination() +" is " +
                           taxi1.compareFair(taxi2) + " than " +taxi2.getDestination());
    }
    
}
