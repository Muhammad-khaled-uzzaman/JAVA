
package Cricketer;

public class Batsman {
    
    private String name;
    private String country;
    private int age;
    private int info[][] = new int [2][15];
    
    public Batsman(){
        
    }
    public Batsman(String name,String country,int age,int info){
        this.name = name;
        this.country = country;
        this.age = age;
        this.info[2][15] =info;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int[][] getInfo() {
        return info;
    }

    public void setInfo(int[][] info) {
        this.info = info;
    }
    
    public int[] matchStatus(int matchNum){
        int status[] = new int[2];
        status[0] = info[0][matchNum];
        status[1] = info[0][matchNum];
        return status;
    }
    
}
