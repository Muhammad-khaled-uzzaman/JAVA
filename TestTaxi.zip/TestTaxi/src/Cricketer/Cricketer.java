
package Cricketer;

public class Cricketer {
    
    static void calculateAvg(Batsman ob){
        int CricketerRun;
        int arr[][] = ob.getInfo();
        for (int i = 0; i < ob.getInfo().length; i++) {
            if (arr[0][i] == 0) {
                ob.matchStatus(i);
            }
        }
    }
}
