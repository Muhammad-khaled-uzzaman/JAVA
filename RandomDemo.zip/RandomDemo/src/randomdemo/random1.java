//Random number generator
package randomdemo;

import java.util.Random;

public class random1 {
    public static void main(String[] args) {
        
        Random rand = new Random();
        
        int randomNumber = rand.nextInt(10)+1;  //0 to 9
        
        System.out.println("Random Number : "+randomNumber);
    }
}
