
package randomdemo;

public class random2 {
    public static void main(String[] args) {
        
        int randomNumber = (int)(Math.random()*10)+1;
        System.out.println("Random number : "+randomNumber);
    }
}
