
package swing2;


import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.util.logging.Handler;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;



public class ActionListener extends JFrame {
      private Container c;
    private JTextField tf1,tf2;
    ActionListener()
    {
        initComponents();
    }
    public void initComponents()
    {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.yellow);
        
         tf1 = new JTextField();
        tf1.setBounds(50, 50, 200, 50);
        c.add(tf1);
        
        tf2 = new JTextField();
        tf2.setBounds(50, 110, 200, 50);
        c.add(tf2);
        
        Handler handler = new Handler();
        tf1.addActionListener((java.awt.event.ActionListener) handler);
        tf2.addActionListener((java.awt.event.ActionListener) handler);
    }
       class Handler extends ActionListener{
         public void actionPerformed(ActionEvent e)
            {
                if(e.getSource()==tf1)
                {
                    String s =tf1.getText();
                
                if(s.isEmpty())
                {
                    JOptionPane.showMessageDialog(null,"You didnt enter anything");
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"tf1 = "+s);
                }
            }
                else
                {
                    String s =tf2.getText();
                
                if(s.isEmpty())
                {
                    JOptionPane.showMessageDialog(null,"You didnt enter anything");
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"tf2 = "+s);
                }
            }
                
                }
    }
    public static void main(String[] args) {
        ActionListener frame = new ActionListener();
        
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200,50,500,400);
        frame.setTitle("ActionListener Demo");
        
        
    }
    
}
