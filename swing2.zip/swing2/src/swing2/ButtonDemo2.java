
package swing2;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;

public class ButtonDemo2 extends JFrame {
    private Container c;
     private JButton btn1,btn2;
     private Font f;
    private Cursor cursor;
    ButtonDemo2()
    {
        initComponents();
    }
    public void initComponents()
    {
        
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.RED);
        
         f = new Font("Arial",Font.ITALIC,18);
        
        cursor = new Cursor(Cursor.HAND_CURSOR);
        
        btn1 = new JButton("Submit");
        btn1.setFont(f);
        btn1.setCursor(cursor);
        btn1.setBounds(100, 50, 100, 50);
        c.add(btn1);
        
           
        btn2 = new JButton("Clear");
        btn2.setFont(f);
        btn2.setCursor(cursor);
        btn2.setBounds(210, 50, 100, 50);
         c.add(btn2);
         
         
    }
    
    public static void main(String[] args) {
        ButtonDemo2 frame = new ButtonDemo2();
        
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200,50,500,400);
        frame.setTitle("Button Demo");
        
        
    }
    
}
