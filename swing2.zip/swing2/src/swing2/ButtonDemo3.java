
package swing2;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class ButtonDemo3 extends JFrame {
    private Container c;
    private JButton btn1,btn2;
    private Font f;
    private Cursor cursor;
    private ImageIcon img1,img2;
    
    ButtonDemo3()
    {
        initComponents();
    }
    public void initComponents()
    {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.RED);
        
         f = new Font("Arial",Font.ITALIC,18);
        
        cursor = new Cursor(Cursor.HAND_CURSOR);
        img1 = new ImageIcon(getClass().getResource("login.jpg"));
        img2 = new ImageIcon(getClass().getResource("clear.jpg"));
        
        btn1 = new JButton(img1);
        btn1.setFont(f);
        btn1.setCursor(cursor);
        btn1.setBounds(100, 50, 200, 50);
        c.add(btn1);
        
           
        btn2 = new JButton(img2);
        btn2.setFont(f);
        btn2.setCursor(cursor);
        btn2.setBounds(310, 50, 200, 50);
        c.add(btn2);
    }
    public static void main(String[] args) {
        ButtonDemo3 frame = new ButtonDemo3();
        
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200,50,650,400);
        frame.setTitle("Button Demo");
        
        
    }
    
}
