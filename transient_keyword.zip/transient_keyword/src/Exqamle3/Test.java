
package Exqamle3;


public class Test  {
     transient int i = 10;
    public static void main(String[] args) {
        Test t = new Test();
        System.out.println(t.i);
        
    }
}
