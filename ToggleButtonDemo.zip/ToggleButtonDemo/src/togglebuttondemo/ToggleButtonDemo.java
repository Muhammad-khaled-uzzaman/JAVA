
package togglebuttondemo;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JToggleButton;

public class ToggleButtonDemo extends JFrame implements ActionListener {
    private Container c;
    private JToggleButton tb;
    private JLabel label;
    private ImageIcon onIcon,offIcon;
    ToggleButtonDemo()
    {
        initComponents();
    }
    public void initComponents()
    {
          c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.PINK);
        
        onIcon = new ImageIcon("src/image/on.png");
        offIcon = new ImageIcon("src/image/off.png");
        
        tb = new JToggleButton(offIcon);
        tb.setBounds(50,50,210,120);
        c.add(tb);
        
        label = new JLabel("Hello there");
        label.setVisible(false);
        label.setBounds(50, 180, 150, 50);
        c.add(label);
        
        tb.addActionListener(this);
    }
    public void actionPerformed(ActionEvent ae) {
        if(tb.isSelected())
        {
            //tb.setText("ON");
            tb.setIcon(onIcon);
            label.setVisible(true);
        }
        else
        {
            //tb.setText("OFF");
            tb.setIcon(offIcon);
            label.setVisible(false);
        }
    }
    
    public static void main(String[] args) {
        ToggleButtonDemo frame = new  ToggleButtonDemo();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,400,300);
        frame.setTitle("Toggle Button Demo");
    }

   
    
    
}
