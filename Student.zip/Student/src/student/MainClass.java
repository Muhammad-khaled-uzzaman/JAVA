
package student;

public class MainClass {
    
    public static void main(String[] args) {
        Student s[] = new Student[3];
        s[0] = new Student("Khaled",102,"C");
        s[1] = new Student("Masum",302,"A");
        s[2] = new Student("Pinky",402,"B");
        
        Student student = new Student();
        System.out.println(student.find(s, "Khaled"));
        System.out.println(student.find(s, 502));
    }
}
