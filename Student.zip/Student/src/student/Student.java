package student;

public class Student {

    private String name;
    private int Id;
    private String section;

    public Student() {

    }

    public Student(String name, int Id, String section) {
        this.name = name;
        this.Id = Id;
        this.section = section;
    }

    public String find(Student s[], String name) {
        String student = "Student is Not found";

        for (int i = 0; i < s.length; i++) {
            if (s[i].name.equals(name)) {
                student = "Student is found";
            }
        }

        return student;
    }

    public String find(Student s[], int id) {
        String student = "Student is Not found";

        for (int i = 0; i < s.length; i++) {
            if (s[i].Id == id) {
                student = "Student is found";
            }
        }

        return student;
    }
}
