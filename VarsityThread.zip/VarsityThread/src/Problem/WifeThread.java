
package Problem;

import java.util.Random;

public class WifeThread implements Runnable {
    
     SharedAccount sc;

    WifeThread(SharedAccount sc) {

        this.sc = sc;

    }

    void Wifedipositor() {

        Random rm = new Random();

        sc.deposit(rm.nextInt(500), "Wife");

    }

    void WifeWithDrawer() {

        Random rm = new Random();

        sc.withdraw(rm.nextInt(500), "Wife");
    }

    @Override
    public void run() {

        for (int i = 0; i < 3; i++) {

             //Wifedipositor();
            WifeWithDrawer();
        }
    }
}
