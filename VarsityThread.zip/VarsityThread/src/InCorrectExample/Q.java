package InCorrectExample;

public class Q {

    int head = 0;
    int tail = 0;

    int qu[] = new int[50000];

    synchronized void push(int k) {
        qu[head] = k;

        System.out.println("Producer : " + "[" + head + "] : " + qu[head]);

        head++;
    }

    synchronized void pop() {

        System.out.println("Consumer : " + "[" + tail + "] : " + qu[tail]);

        tail++;
    }
}
