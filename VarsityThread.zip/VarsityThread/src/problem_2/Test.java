package problem_2;

public class Test {

    public static void main(String[] args) {
        SharedAccount account = new SharedAccount();
        HusbandThread ht = new HusbandThread(account);
        WifeThread wt = new WifeThread(account);
        Thread t1 = new Thread(ht);
        Thread t2 = new Thread(wt);

        t1.start();
        t2.start();
    }
}
