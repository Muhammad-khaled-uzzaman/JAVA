package problem_2;

import java.util.Random;

public class HusbandThread implements Runnable {

    SharedAccount sc;

    HusbandThread(SharedAccount sc) {
        this.sc = sc;
    }

    void Husbanddipositor() {
        Random rm = new Random();
        sc.deposit(rm.nextInt(500), "Husband");

    }

    void HusbandWithDrawer() {
        Random rm = new Random();
        sc.withdraw(rm.nextInt(500), "Husband");

    }

    @Override
    public void run() {
        for (int i = 0; i < 2; i++) {
            // Husbanddipositor();
            //	Husbanddipositor();
            HusbandWithDrawer();
        }
    }
}
