package Example_2;

public class NT implements Runnable {

    Thread t;

    NT() {
        t = new Thread(this, "thread demo");

        t.start();
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 5; i++) {
                System.out.println("Child thread : " + i);
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            System.out.println("Child Interrupted");
        }
        System.out.println("exiting child thread");
    }

}
