package CorrectExample;

public class Q {

    int head = 0;
    int tail = 0;

    int qu[] = new int[50000];

    boolean ispush = false;

    synchronized void push(int k) {
        if (ispush) {

            try {
                wait();
            } catch (InterruptedException e) {
                System.out.println("push Interrupted");
            }
        }
        ispush = true;
        qu[head] = k;

        System.out.println("Producer : " + "[" + head + "] : " + qu[head]);
        head++;
        notify();

    }

    synchronized void pop() {

        if (!ispush) {
            try {
                wait();
            } catch (InterruptedException e) {
                System.out.println("Pop Interruted");
            }
        }

        ispush = false;
        System.out.println("Consumer : " + "[" + tail + "] : " + qu[tail]);

        tail++;

        notify();
    }
}
