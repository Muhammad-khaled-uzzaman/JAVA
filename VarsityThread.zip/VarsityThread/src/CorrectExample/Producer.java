
package CorrectExample;

import java.util.Random;

public class Producer implements Runnable {
    
    Random r = new Random();
    Q q;
    
    Producer(Q q){
        this.q = q;
        
        new Thread(this,"Producer").start();
    }
    
    @Override
    public void run(){
        int k;
        while(true){
            k = r.nextInt(500);
            q.push(k);
        }
    }
}
