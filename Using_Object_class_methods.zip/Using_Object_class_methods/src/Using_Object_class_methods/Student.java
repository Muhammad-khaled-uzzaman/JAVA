
// Java program to demonstrate working of 
// hasCode() and toString() 

package Using_Object_class_methods;

public class Student {
    
    static int last_roll =100;
    int roll_no;
    
    Student(){
        roll_no = last_roll;
        last_roll++;
    }
    
    // Overriding hashCode()     
    @Override
    public int hashCode(){
        return roll_no;
    }
    
    public static void main(String[] args) {
        Student s = new Student();
        System.out.println(s.roll_no);
        System.out.println(s.last_roll);
        System.out.println(s);
        System.out.println(s.toString());
    }
}
