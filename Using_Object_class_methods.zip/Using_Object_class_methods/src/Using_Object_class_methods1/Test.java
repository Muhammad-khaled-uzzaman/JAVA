//// Java program to demonstrate working of getClass() 
package Using_Object_class_methods1;

public class Test {
      
    public static void main(String[] args) {
        
        Object ob = new String("Muhammad");
        Class c = ob.getClass();
        
        System.out.println("Class of Object ob is : "+c.getName());
    }
}
