
package slideshow;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SlideshowDemo extends JFrame implements ActionListener {
    private Container c;
    private JButton btn1,btn2;
    private JPanel panel;
    private ImageIcon icon;
    private JLabel label;
    private CardLayout card;
    SlideshowDemo()
    {
        initComponents();
        showImage();
    }
    public void showImage()
    {
        String [] imageNames = {"1.jpg","2.jpg","3.jpg","4.jpg","5.jpg","6.jpg","7.jpg","8.jpg"};
        for(String n : imageNames)
        {
             icon = new ImageIcon("src/khaled/"+n);
             
             Image img = icon.getImage();
             Image newImage = img.getScaledInstance(panel.getWidth(), panel.getHeight(), Image.SCALE_SMOOTH);
             icon = new ImageIcon(newImage);
             label = new JLabel(icon);
             panel.add(label);
        }
    }
    public void initComponents()
    {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.PINK);
        
        card = new CardLayout();
        
        panel = new JPanel(card);
        panel.setBounds(10,10,560,380);
        c.add(panel);
        
        btn1 = new JButton("Previous");
        btn1.setBounds(10,400,100,50);
        c.add(btn1);
        
        btn2 = new JButton("Next");
        btn2.setBounds(470,400,100,50);
        c.add(btn2);
        btn1.addActionListener(this);
        btn2.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource()==btn1)
        {
            card.previous(panel);
        }
       
        if(e.getSource()==btn2)
        {
            card.next(panel);
        }
    }
    public static void main(String[] args) {
        SlideshowDemo frame = new  SlideshowDemo();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,600,500);
        frame.setTitle("Slideshow Demo ");
    }

    
    
}
