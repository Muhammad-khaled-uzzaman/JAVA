/*
if the superclass is serializable but we don’t want the subclass to be serialized : 
*/
// Java program to demonstrate  
// how to prevent  
// subclass from serialization 
package Example3;
import java.io.*;
public class A implements Serializable {
    
    int i;
    
    public A(int i){
        this.i = i;
    }
}
