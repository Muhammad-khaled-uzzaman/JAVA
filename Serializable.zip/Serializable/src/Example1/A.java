/*
Case 1: If superclass is serializable then subclass is automatically serializable
*/
// Java program to demonstrate  
// that if superclass is 
// serializable then subclass  
// is automatically serializable 
package Example1;
import java.io.*;
// superclass A  
// implementing Serializable interface
public class A implements Serializable {
    
    int i;
    
    public  A(int i){
        this.i = i;
    }
}
