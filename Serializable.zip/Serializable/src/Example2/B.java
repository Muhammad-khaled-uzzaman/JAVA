package Example2;

import java.io.*;

public class B extends A implements Serializable {

    int j;

    public B(int i, int j) {
        super(i);
        this.j = j;
    }
}
