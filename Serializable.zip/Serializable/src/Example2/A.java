/*
If a superclass is not serializable then subclass can still be serialized 
 */
// Java program to demonstrate  
// the case if superclass need 
// not to be serializable  
// while serializing subclass  
package Example2;

import java.io.*;

public class A {

    int i;

    public A(int i) {
        this.i = i;
    }

    public A() {

        i = 50;
        System.out.println("A's class constructor called");
    }
}
