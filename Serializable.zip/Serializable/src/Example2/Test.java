
package Example2;
import java.io.*;
public class Test {
    public static void main(String[] args) throws Exception {
        B b1 = new B(10,20);
        System.out.println("i = "+b1.i);
        System.out.println("j = "+b1.j);
        
        // Serializing B's(subclass) object  
          
        //Saving of object in a file 
        FileOutputStream fos =new FileOutputStream("file.txt");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        
        oos.writeObject(b1);
        
        oos.close();
        fos.close();
        
        System.out.println("Object has been serialized");
        
        FileInputStream fis = new FileInputStream("file.txt");
        ObjectInputStream ois = new ObjectInputStream(fis);
        
        B b2 =(B)ois.readObject();
        
        ois.close();
        fis.close();
        
        System.out.println("Object has been deserialized");
        System.out.println("i = "+b2.i);
        System.out.println("j = "+b2.j);
    }
}
