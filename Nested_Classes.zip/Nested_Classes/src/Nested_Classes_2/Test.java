
package Nested_Classes_2;

public class Test {
    
    public static void main(String[] args) {
        
        OuterClass outerObject = new OuterClass();
        
        OuterClass.InnerClass innerObject = outerObject.new InnerClass();
        
        innerObject.display();
    }
}
