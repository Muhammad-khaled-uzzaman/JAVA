
package Nested_Classes_1;

public class Test {
    
    public static void main(String[] args) {
        // accessing a static nested class 
        OuterClass.StaticNestedClass object = new OuterClass.StaticNestedClass();
        
        object.display();
    }
}
