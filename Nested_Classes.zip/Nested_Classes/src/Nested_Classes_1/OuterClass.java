
package Nested_Classes_1;

public class OuterClass {
    
    static int outer_x = 10;
    
    int outer_y = 20;
    
    private static int outer_private = 30;
    
    static class StaticNestedClass{
        void display(){
            
            System.out.println("outer_x : "+outer_x);
            
            System.out.println("outer_private : "+outer_private);
            
            // as static nested class cannot directly access non-static membera 
            //System.out.println("outer_y : "+outer_y);
        }
    }
}
