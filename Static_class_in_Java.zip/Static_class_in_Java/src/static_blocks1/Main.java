
package static_blocks1;

public class Main {
    public static void main(String[] args) {
        // Although we have two objects, static block is executed only once.
        Test t1 = new Test();
        Test t2 = new Test();
        System.out.println(t2.i);
        System.out.println(t2.j);
        
    }
}
