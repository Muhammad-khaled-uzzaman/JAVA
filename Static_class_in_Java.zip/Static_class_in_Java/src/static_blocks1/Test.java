/*
Also, static blocks are executed before constructors. For example, 
check output of following Java program.
*/
package static_blocks1;

public class Test {
    
    static int i;
    int j;
    
    static{
        System.out.println("static block called");
    }
    Test(){
        i = 5;
        j =10;
        System.out.println("Constructor called");
    }
}
