
package Static_class_in_Java;

public class Main {
    public static void main(String[] args) {
        OuterClass.NestedStaticClass printer = new OuterClass.NestedStaticClass();
        
        printer.printMessage();
        
        
        OuterClass outer = new OuterClass();
        OuterClass.InnerClass inner  = outer.new InnerClass(); 
        
        inner.display();
        
        OuterClass.InnerClass innerObject  = outer.new InnerClass(); 
        
        innerObject.display();
        
    }
}
