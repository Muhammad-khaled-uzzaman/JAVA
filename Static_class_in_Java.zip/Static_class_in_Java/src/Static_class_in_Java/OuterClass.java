
package Static_class_in_Java;

public class OuterClass {
    
   private static String msg ="Muhammad Khaleduzzaman";
    public static class NestedStaticClass{
        // Only static members of Outer class is directly accessible in nested  
       // static class  
        public void printMessage(){
            System.out.println("Message from nested static class : "+msg);
        }
    }
    
       // Both static and non-static members of Outer class are accessible in
    // this Inner class 
    public class InnerClass{
        
        public void display(){
            System.out.println("Message from non-static nested class : "+msg);
        }
    }
}
