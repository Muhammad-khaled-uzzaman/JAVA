/*
Static blocks in Java
*/
package static_blocks;

public class Test {
    static int i;
    int j;
    static{
        i = 10;
        System.out.println("static block called");
    }
    
}
