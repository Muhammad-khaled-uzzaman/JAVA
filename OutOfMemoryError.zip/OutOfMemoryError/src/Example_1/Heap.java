/*
Understanding OutOfMemoryError Exception in Java
 */
package Example_1;

import java.util.ArrayList;

public class Heap {

    static ArrayList<String> list = new ArrayList<String>();

    public static void main(String[] args) throws Exception {
        Integer[] array = new Integer[10000 * 10000];
    }
}
