/*
// Java program to illustrate 
// GC Overhead limit exceeded 
*/
package Example_2;

import java.util.*;

public class Wrapper {
    
    public static void main(String[] args) throws Exception {
        Map m = new HashMap();
        m = System.getProperties();
        Random r = new Random();
        while(true){
            m.put(r.nextInt(), "randomValue");
        }
    }
}
