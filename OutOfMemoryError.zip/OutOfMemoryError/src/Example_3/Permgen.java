
// Java program to illustrate 
// Permgen Space error 
package Example_3;
//import javassist.ClassPool;
public class Permgen {
    //ClassPool classpool = ClassPool.getDefault();
    public static void main(String args[]) throws Exception 
    { 
        for (int i = 0; i < 1000000000; i++) { 
            //Class c = classPool.makeClass(com.saket.demo.Permgen" + i).toClass(); 
            //System.out.println(c.getName()); 
        } 
    } 
}
