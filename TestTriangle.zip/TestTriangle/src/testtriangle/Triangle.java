package testtriangle;

public class Triangle {

    private int triangleId;
    private String color;
    private float side;

    public Triangle() {

    }

    public Triangle(int triangleId, String color, float side) {
        this.triangleId = triangleId;
        this.color = color;
        this.side = side;

    }

    public float getArea(Triangle are[], int findById) {
        float area = 0.0f;

        for (int i = 0; i < are.length; i++) {
            if (are[i].triangleId == findById) {
                area = 3.1416f * are[i].side * are[i].side;
            }
        }
        return area;
    }

    public float getArea(Triangle are[], String findByColor) {

        float area = 0.0f;

        for (int i = 0; i < are.length; i++) {
            if (are[i].color.equals(findByColor)) {
                area = 3.1416f * are[i].side * are[i].side;
            }
        }
        return area;
    }
}
