package testtriangle;

public class TestTriangle {

    public static void main(String[] args) {
        Triangle area[] = new Triangle[3];
        area[0] = new Triangle(301, "Black", 1.5f);
        area[1] = new Triangle(302, "Orange", 3f);
        area[2] = new Triangle(303, "Violet", 6f);

        Triangle ob = new Triangle();
        System.out.println(ob.getArea(area, 301));
        System.out.println(ob.getArea(area, "Violet"));
    }
}
