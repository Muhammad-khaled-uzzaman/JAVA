package stringdemo;

public class String13 {
    
    public static void main(String[] args) {
        
        StringBuffer sb = new StringBuffer("GeeksforGeek");
        
        String str = sb.substring(5);
        System.out.println(str);
        
        String str1 = sb.substring(5, 8);
        System.out.println(str1);
        
        System.out.println(sb.subSequence(0, 5));
        
    }
}
