package stringdemo;

import java.util.Arrays;

public class String20 {

    public static void main(String[] args) {
        StringBuffer str= new StringBuffer("Geeks For Geeks");

        // print string 
        System.out.println("String = "
                + str.toString());

        // create a char Array 
        char[] array = new char[15];

        // initialize all character to .(dot). 
        Arrays.fill(array, '.');

        // get char from index 0 to 9 
        // and store in array start index 3 
        str.getChars(0, 9, array, 1);
        

        // print char array after opeartion 
        System.out.print("char array contains : ");

        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }

    }
}
