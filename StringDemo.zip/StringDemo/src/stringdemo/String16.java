
package stringdemo;

public class String16 {
    
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("ABCDEFGHIJ");
        
        System.out.println(sb.toString());
        
        int code = sb.codePointAt(0);
        System.out.println(code);
        
        code = sb.codePointBefore(2);
        System.out.println(code);
        
        code = sb.codePointCount(0, 2);
        System.out.println(code);
    }
}
