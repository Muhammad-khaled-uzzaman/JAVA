
package stringdemo;

public class String7 {
    public static void main(String[] args) {
        
        StringBuilder str = new StringBuilder("Khaled");
        System.out.println("str = "+str);
        
        str.append("uzzaman");
        str.append(25);
        str.append(12.5);
        System.out.println("str = "+str);
       
        str.reverse();
        System.out.println("str = "+str);

        str.delete(0, 5);
        System.out.println("str = "+str);
        
        
        
        String sm = "dddd";    
        
        boolean s = sm.endsWith("d");
        System.out.println(s);
        
        char c = sm.charAt(0);
        System.out.println(c);
        
        
    
    }
    
}
