
package stringdemo;

public class String2 {
    public static void main(String[] args) {
        String firstName = "Muhammad";
        String lastName = " Khaled";
        
        String fullName = firstName + lastName;
        System.out.println("Full Name = "+fullName+25);
        
        fullName = firstName.concat(lastName);
        System.out.println("Full Name = "+fullName);
        
        String upperName = fullName.toUpperCase();
        System.out.println("Upper Name = "+upperName);
        
        String lowerName = fullName.toLowerCase();
        System.out.println("lower Name = "+lowerName);
        
        boolean b = firstName.startsWith("M");
        System.out.println("b = "+b);
        
        boolean last = lastName.endsWith("d");
        System.out.println("last = "+last);
        
        String [] names ={"Agun","khaled","Masum","Muhsin"};
        
        for(String x : names)
        {
            System.out.println(x);
        }
        System.out.println();
        
        for (int i = 0; i < 4; i++) {
            System.out.println(names[i]);
            
        }
        
    }
}
