
package stringdemo;

public class String15 {
    
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("MuhammadKhaled");
        
        for (int i = 0; i < sb.length(); i++) {
            System.out.println(sb.charAt(i));
        }
    }
}
