
package stringdemo;

public class String11 {
    
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("Bangladeshss Indian");
        
        sb.replace(10, 13," vs ");
        System.out.println(sb);
        
        StringBuffer sb1 = new StringBuffer("Muhammad jjjled");
        sb1.replace(8,12, " kha");
        System.out.println(sb1);    }
}
