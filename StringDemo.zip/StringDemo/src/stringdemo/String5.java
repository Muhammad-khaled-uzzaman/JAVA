
package stringdemo;

public class String5 {
    public static void main(String[] args) {
        
        String s1 ="Khaled";
        StringBuffer sb = new StringBuffer(s1);
        System.out.println(sb);
        
        sb.append("uzzaman ");
        sb.append(25);
        System.out.println(sb);
        
        sb.reverse();
        System.out.println(sb);
        
        sb.delete(0, 5);
        System.out.println(sb);
        
        sb.setLength(5);
        System.out.println(sb);
        
    }
}
