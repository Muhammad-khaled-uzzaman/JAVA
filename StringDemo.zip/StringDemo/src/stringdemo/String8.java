package stringdemo;

public class String8 {

    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("A");

        System.out.println(sb);

        sb.appendCodePoint(66);
        System.out.println(sb);
        char ch = 'C';
        sb.append(ch);
        System.out.println(sb);

        String s = "D";

        sb.append(s);
        System.out.println(sb);

        //sb.append(true);
        //System.out.println(sb);
        sb.append('E');

        System.out.println(sb);

        char c[] = {'F', 'G'};
        sb.append(c);

        System.out.println(sb);
        char c1[] = {'H', 'I', 'J'};
        sb.append(c1, 0, 3);
        System.out.println(sb);

        sb.append(sb, 0, 10);
        System.out.println(sb);
        sb.append(100.5);
        System.out.println(sb);
        
        CharSequence cs= "geeks";
        
        sb.append(cs);
        System.out.println(sb);
    }
}
