
package stringdemo;

public class String10 {
    
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("MuhamadKhaled");
        
        sb.delete(0, 2);
        System.out.println(sb);
        
        sb.deleteCharAt(3);
        System.out.println(sb);
    }
}
