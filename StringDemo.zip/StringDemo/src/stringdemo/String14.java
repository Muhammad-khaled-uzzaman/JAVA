
package stringdemo;

public class String14 {
    
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("MuhammadKhaled");
        
        System.out.println(sb.toString());
        
        sb.setCharAt(7, 'G');
        System.out.println(sb);
        System.out.println(sb.toString());
        
        char c = sb.charAt(0);
        System.out.println(c);
    }
}
