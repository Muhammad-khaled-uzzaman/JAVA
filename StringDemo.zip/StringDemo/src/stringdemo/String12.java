
package stringdemo;

public class String12 {
    
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("Muhammad Khaleduzzaman");
        
        sb.reverse();
        System.out.println(sb);
        
        StringBuffer sb1 = new StringBuffer("0 1 2 3 4 5 6 7 8 9 10");
        
        sb1.reverse();
        System.out.println(sb1);
        
        sb1.reverse();
        System.out.println(sb1);
    }
}
