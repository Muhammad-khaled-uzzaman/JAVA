
package stringdemo;

public class String17 {
    
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("Muhammad Khaled");
        
        System.out.println(sb.capacity());
        
        sb.ensureCapacity(42);
        
        System.out.println(sb.capacity());
        
        StringBuffer sb1 = new StringBuffer("mmm kk");
        
        System.out.println(sb1.capacity());
        
        StringBuffer sb2 = new StringBuffer();
        System.out.println(sb2.capacity());
        
        sb2.ensureCapacity(18);
        System.out.println(sb2);
        
    }
}
