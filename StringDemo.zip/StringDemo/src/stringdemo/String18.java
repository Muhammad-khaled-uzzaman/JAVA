
package stringdemo;

public class String18 {
    
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("Bangladesh is great");
        
        System.out.println(sb.toString());
        
       int value =  sb.offsetByCodePoints(1, 9);
        System.out.println(value);
    }
}
