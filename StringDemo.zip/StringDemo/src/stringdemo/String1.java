
package stringdemo;

public class String1 {
    public static void main(String[] args) {
        String s1 = "Muhammad Khaled";
        String s2 = new String("muhammad Khaled");
        
        char[] s3 = {'K','h','a','l','e','d'};
        
        
        System.out.println("S1 = "+s1); 
        System.out.println("S2 = "+s2); 
        System.out.println(s3); 
        int len = s1.length();
        System.out.println("Length of s1 = "+len);
        //s1.contains(s2)
        if(s1.equals(s2))
        {
            System.out.println("Equals");
        }
        else
        {
            System.out.println("Not Equals");
        }
        if(s1.contains("Khaled"))
        {
            System.out.println("Equals");
        }
        else
        {
            System.out.println("Not Equals");
        }
        if(s1.equalsIgnoreCase(s2))
        {
            System.out.println("Equals");
        }
        else
        {
            System.out.println("Not Equals");
        }
        boolean con = s1.contains("Muhammad");
        System.out.println(con);
        boolean b = s1.isEmpty();
        System.out.println("b = "+b);
           
    }
}
