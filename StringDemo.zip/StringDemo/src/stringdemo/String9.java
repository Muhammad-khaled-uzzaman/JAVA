package stringdemo;

public class String9 {

    public static void main(String[] args) {
        
        StringBuffer sb = new StringBuffer("Muhammadkhaled");
        
        System.out.println(sb);
        
        int index = sb.indexOf("h");
        System.out.println(index);
        
        index = sb.indexOf("h", 3);
        System.out.println(index);
        
        index = sb.lastIndexOf("a");
        System.out.println(index);
        
        index = sb.lastIndexOf("a",6);
        System.out.println(index);
    }
    
}
