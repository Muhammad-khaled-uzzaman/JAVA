
package stringdemo;

public class String19 {
    
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("Khaled");
        System.out.println(sb.capacity());
        
        sb.trimToSize();
        
        System.out.println(sb.capacity());
    }
}
