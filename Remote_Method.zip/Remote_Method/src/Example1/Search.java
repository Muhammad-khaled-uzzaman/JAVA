/*
Step 1: Defining the remote interface
 */
package Example1;

import java.rmi.*;

public interface Search extends Remote {

    // Declaring the method prototype 
    public String query(String search) throws RemoteException  ;
}
