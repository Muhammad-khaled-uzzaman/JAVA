
package Examle12;

public class A extends Test {
    
}
