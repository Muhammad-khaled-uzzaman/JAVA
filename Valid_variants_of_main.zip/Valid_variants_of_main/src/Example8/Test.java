/*
synchronized keyword to static main method: We can make main() synchronized
*/
package Example8;

public class Test {
    public synchronized static void main(String[] args) {
        System.out.println("Main Method");
    }
}
