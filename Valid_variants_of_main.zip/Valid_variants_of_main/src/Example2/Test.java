
package Example2;

public class Test {
    static public void main(String[] args){
        System.out.println("Main Method");
    
    }    
}
