
package Example11;

public class Test {
    public static void main(String[] args) {
        System.out.println("Main Method String Array");
    }
    
    public static void main(int[] args) {
        System.out.println("Main Method int Array");
    }
}
