/*
Final Modifier String argument: We can make String args[] as final.
*/
package Example6;

public class Test {
    public static void main(final String[] args) {
        System.out.println("Main Method");
    }
}
