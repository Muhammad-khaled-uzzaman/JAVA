/*
Combinations of all above keyword to static main method:
*/
package Example10;

public class Test {
    public final synchronized strictfp static void main(String[] args) 
    { 
        System.out.println("Main Method"); 
    } 
}
