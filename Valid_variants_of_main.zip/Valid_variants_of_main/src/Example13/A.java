/*
Method Hiding of main(), but not Overriding: Since main() is static, 
derived class main() hides the base class main.
*/
package Example13;

public class A {
    public static void main(String[] args) {
        System.out.println("Main Method Parent");
    }
}
