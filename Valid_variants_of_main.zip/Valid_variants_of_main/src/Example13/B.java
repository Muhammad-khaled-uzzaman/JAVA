
package Example13;

public class B extends A {
    public static void main(String[] args) {
        System.out.println("Main Method Child");
    }
}
