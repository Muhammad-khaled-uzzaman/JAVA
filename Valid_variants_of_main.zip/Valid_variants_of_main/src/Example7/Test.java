/*
Final Modifier to static main method: We can make main() as final.
*/
package Example7;

public class Test {
    public final static void main(String[] args) {
        System.out.println("Main Method");
    }
}
