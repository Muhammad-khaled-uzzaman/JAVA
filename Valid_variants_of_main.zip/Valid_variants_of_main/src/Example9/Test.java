/*
strictfp keyword to static main method: strictfp can 
be used to restrict floating point 
*/
package Example9;

public class Test {
    public strictfp static void main(String[] args) {
        System.out.println("Main method");
    }
}
