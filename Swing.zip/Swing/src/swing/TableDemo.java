

package swing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class TableDemo extends JFrame {
    private Container c;
    private JTable table;
    private JLabel label;
    private Font f;
    private JScrollPane scroll;
    
    private String[] cols = {"ID","Name","CGPA"};
    private String[][] rows = {
    
            {"101","Md Masum","3.21"},
            {"102","Md Mamum","3.00"},
            {"103","Tamim Ahmed","3.94"},
            {"104","Md Alif","3.75"},
            {"105","Md Khaled","2.00"},
            {"106","Daud Kabir","3.30"},
            {"107","Asif Muhammad","3.50"},
            {"108","Shakib Hossain","3.83"},
            {"109","Murad Khan","3.45"},
            {"110","Arman Hossain","3.88"}
    
    
    
    };
    TableDemo()
    {
        initComponents();
    }
    public void initComponents()
    {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.PINK);
        
        f = new Font("Arial",Font.BOLD,18);
        label = new JLabel("Students Details");
        label.setBounds(300,20,200,50);
        label.setFont(f);
        c.add(label);
        
        table = new JTable(rows,cols);
        table.setSelectionBackground(Color.PINK);
        //table.setEnabled(false);
        scroll = new JScrollPane(table);
        scroll.setBounds(50,80,600,150);
        c.add(scroll);
    }
    public static void main(String[] args) {
        TableDemo frame = new  TableDemo();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,750,450);
        frame.setTitle("Table Demo");
    }
}
