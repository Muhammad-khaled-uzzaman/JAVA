
package swing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JRadioButton;

public class JRadioButtonDemo extends JFrame {
    private Container c;
    private JRadioButton male,female;
    private ButtonGroup grp;
    private Font f;
    
    JRadioButtonDemo()
    {
        initComponents();
    }
    public void initComponents()
    {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(100,50,400,400);
        this.setTitle("JRadioButton Demo");
        
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.YELLOW);
        
        f = new Font("Arial",Font.BOLD,18);
        
        grp = new ButtonGroup();
        
        male = new JRadioButton("Male");
        male.setBounds(50,50,100,50);
        male.setBackground(Color.YELLOW);
        male.setFont(f);
        c.add(male);
        
        female = new JRadioButton("Female");
        female.setBounds(230,50,100,50);
        female.setBackground(Color.YELLOW);
        female.setFont(f);
        c.add(female);
        
        grp.add(male);
        grp.add(female);
        
    }
    public static void main(String[] args) {
        JRadioButtonDemo frame = new JRadioButtonDemo();
        frame.setVisible(true);
        
    }
    
}
