
package swing;

import java.awt.Color;
import java.awt.Container;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class TabbedPane extends JFrame {
    private Container c;
    private JTabbedPane tp;
    private JPanel panel1,panel2,panel3;
    private JLabel label1,label2,label3;
    private ImageIcon homeIcon,helpIcon;
    TabbedPane()
    {
        initComponents();
    }
    public void initComponents()
    {
        c = this.getContentPane();
        c.setLayout(null);
       
        tp = new JTabbedPane();
        //tp.setTabPlacement(JTabbedPane.BOTTOM);
        tp.setBounds(50,50,800,700);
        c.add(tp);
        
        homeIcon = new ImageIcon("src/icon/pic.png");
        helpIcon = new ImageIcon("src/icon/pic+.png");
        
        panel1 = new JPanel();
        panel1.setBackground(Color.RED);
        panel2 = new JPanel();
        panel2.setBackground(Color.GREEN);
        panel3 = new JPanel();
        panel3.setBackground(Color.BLUE);
        
        tp.addTab("Home",homeIcon,panel1,"hello i am panel1 tab");
        tp.addTab("Help",helpIcon,panel2);
        tp.addTab("Edit",panel3);
        
        label1 = new JLabel("This is a label1");
        panel1.add(label1);
        label2 = new JLabel("This is a label2");
        panel2.add(label2);
        label3 = new JLabel("This is a label3");
        panel3.add(label3);
    }
    public static void main(String[] args) {
        TabbedPane frame = new  TabbedPane();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,800,700);
        frame.setTitle("TabbedPane Demo");
    }
}
