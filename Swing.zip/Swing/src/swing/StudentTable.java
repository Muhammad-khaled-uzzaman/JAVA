
package swing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class StudentTable extends JFrame implements ActionListener {
    private Container c;
    private Font f;
    private JLabel lb1,lb2,lb3,lb5,lb4;
    private JTextField tf1,tf2,tf3,tf4;
    private JButton btn1,btn2,btn3,btn4;
    private JTable table;
    private JScrollPane scroll;
    private DefaultTableModel model;
    private String[] col = {"First Name","Last Name","Pone Number","GPA"};
    private String[] row = new String[4];
    StudentTable()
    {
        initComponents();
    }
    public void initComponents()
    {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.PINK);
        
        f = new Font("Arial",Font.BOLD,18);
         lb1 = new JLabel("Student Registration");
         lb1.setFont(f);
         lb1.setBounds(280,10,250,50);
         c.add(lb1);
         
         lb2 = new JLabel("First Name ");
         lb2.setFont(f);
         lb2.setBounds(10,80,140,30);
         c.add(lb2);
         
         tf1 = new JTextField();
         tf1.setBounds(110,80,200,30);
         tf1.setFont(f);
         c.add(tf1);
         
         btn1 = new JButton("Add");
         btn1.setBounds(400,80,100,30);
         c.add(btn1);
         
         lb3 = new JLabel("Last Name ");
         lb3.setFont(f);
         lb3.setBounds(10,130,150,30);
         c.add(lb3);
         
         tf2 = new JTextField();
         tf2.setBounds(110,130,200,30);
         tf2.setFont(f);
         c.add(tf2);
         
         btn2 = new JButton("Update");
         btn2.setBounds(400,130,100,30);
         c.add(btn2);
         
         lb4 = new JLabel("Phone ");
         lb4.setFont(f);
         lb4.setBounds(10,180,140,30);
         c.add(lb4);
         
         tf3 = new JTextField();
         tf3.setBounds(110,180,200,30);
         tf3.setFont(f);
         c.add(tf3);
         
         btn3 = new JButton("Delete");
         btn3.setBounds(400,180,100,30);
         c.add(btn3);
         
         lb5 = new JLabel("GPA ");
         lb5.setFont(f);
         lb5.setBounds(10,230,140,30);
         c.add(lb5);
         
         tf4 = new JTextField();
         tf4.setBounds(110,230,200,30);
         tf4.setFont(f);
         c.add(tf4);
         
         btn4 = new JButton("Clear");
         btn4.setBounds(400,230,100,30);
         c.add(btn4);
         
         table = new JTable();
         model = new DefaultTableModel();
         model.setColumnIdentifiers(col);
         table.setModel(model);
         table.setFont(f);
         table.setSelectionBackground(Color.GREEN);
         table.setBackground(Color.WHITE);
         table.setRowHeight(30);
         scroll = new JScrollPane(table);
         scroll.setBounds(10,360,740,265);
         c.add(scroll);
         
         table.addMouseListener(new MouseAdapter(){
         
         public void mouseClicked(MouseEvent me){
             
            int numberOfRow = table.getSelectedRow();
            
            String f_name = model.getValueAt(numberOfRow,0).toString();
            String l_name = model.getValueAt(numberOfRow,1).toString();
            String phone = model.getValueAt(numberOfRow,2).toString();
            String gpa = model.getValueAt(numberOfRow,3).toString();
            
            tf1.setText(f_name);
            tf2.setText(l_name);
            tf3.setText(phone);
            tf4.setText(gpa);
         }
         });
         btn1.addActionListener(this);
         btn4.addActionListener(this);
         btn3.addActionListener(this);
         btn2.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource()==btn1)
        {
            row[0] = tf1.getText();
            row[1] = tf2.getText();
            row[2] = tf3.getText();
            row[3] = tf4.getText();
            model.addRow(row);
        }
        else if(e.getSource()==btn4)
        {
            tf1.setText("");
            tf2.setText("");
            tf3.setText("");
            tf4.setText("");
            
        }
        else if(e.getSource()==btn3)
        {
            int numberOfRow = table.getSelectedRow();
            if(numberOfRow>=0)
            {
                model.removeRow(numberOfRow);
            }
            else
            {
                JOptionPane.showMessageDialog(null,"No row has been selected or no row exits");
            }
        }
        else if(e.getSource()==btn2)
        {
            int numberOfRow = table.getSelectedRow();
            
            
            String f_name = tf1.getText();
            String l_name = tf2.getText();
            String phone = tf3.getText();
            String gpa = tf4.getText();
            
            model.setValueAt(f_name, numberOfRow, 0);
            model.setValueAt(l_name, numberOfRow, 1);
            model.setValueAt(phone, numberOfRow, 2);
            model.setValueAt(gpa, numberOfRow, 3);
        }
        
    }
    public static void main(String[] args) {
        
        
        StudentTable frame = new  StudentTable();
        
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,780,680);
        frame.setTitle("Student Table Demo");
        
       
    }

    
}
