
package swing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class ItemListener extends JFrame {
    private Container c;
    private JCheckBox javaCheckBox,cCheckBox,mysqlCheckBox;
    private ButtonGroup grp;
    private Font f;
    private JLabel label;
    ItemListener()
    {
        initComponents();
    }
    public void initComponents()
    {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(100,50,500,400);
        this.setTitle("JCheckBox Demo");
        
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.MAGENTA);
        
        f = new Font("Arial",Font.BOLD + Font.ITALIC,18);
        
        grp = new ButtonGroup();
        
        javaCheckBox = new JCheckBox("Java");
        javaCheckBox.setBounds(50,100,100,30);
        javaCheckBox.setBackground(Color.MAGENTA);
        javaCheckBox.setFont(f);
        c.add(javaCheckBox);
        
        cCheckBox = new JCheckBox("C");
        cCheckBox.setBounds(50,130,100,30);
        cCheckBox.setBackground(Color.MAGENTA);
        cCheckBox.setFont(f);
        c.add(cCheckBox);
        
        mysqlCheckBox = new JCheckBox("Mysql");
        mysqlCheckBox.setBounds(50,160,100,30);
        mysqlCheckBox.setBackground(Color.MAGENTA);
        mysqlCheckBox.setFont(f);
        c.add(mysqlCheckBox);
        grp.add(javaCheckBox);
        grp.add(cCheckBox);
        grp.add(mysqlCheckBox);
        
        label = new JLabel("You haven't selected anything");
        label.setBounds(50,200,300,30);
        label.setFont(f);
        c.add(label);
        
          Handler handler = new Handler();
      
        
    }
    
     class Handler extends ItemListener{
         
     }
    
    public static void main(String[] args) {
        ItemListener frame = new ItemListener();
        frame.setVisible(true);
    }
    
}
