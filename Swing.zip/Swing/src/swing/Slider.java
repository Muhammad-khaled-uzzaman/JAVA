
package swing;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Slider extends JFrame implements ChangeListener  {
    private Container c;
    private JLabel label1,label2,label3,previewLabel;
    private JSlider slider1,slider2,slider3;
    private JPanel panel;
    private JTextField tf1,tf2,tf3;
    Slider()
    {
        initComponents();
    }
    public void initComponents()
    {
        c = this.getContentPane();
        c.setLayout(null);
        
        label1 = new JLabel("Red");
        label1.setBounds(50,50,80,50);
        c.add(label1);
        
        slider1 = new JSlider(0,255,0);
        slider1.setBounds(90,50,300,50);
        c.add(slider1);
        
        tf1 = new JTextField();
        tf1.setBounds(400,50,80,40);
        tf1.setHorizontalAlignment(JTextField.CENTER);
        c.add(tf1);
        
        
        label2 = new JLabel("Green");
        label2.setBounds(50,110,80,50);
        c.add(label2);
        
        slider2 = new JSlider(0,255,0);
        slider2.setBounds(90,110,300,50);
        c.add(slider2);
        
        tf2 = new JTextField();
        tf2.setBounds(400,110,80,40);
        tf2.setHorizontalAlignment(JTextField.CENTER);
        c.add(tf2);
        
        
        label3 = new JLabel("Blue");
        label3.setBounds(50,170,80,50);
        c.add(label3);
        
         slider3 = new JSlider(0,255,0);
        slider3.setBounds(90,170,300,50);
        c.add(slider3);
        
        tf3 = new JTextField();
        tf3.setBounds(400,170,80,40);
        tf3.setHorizontalAlignment(JTextField.CENTER);
        c.add(tf3);
        
        panel = new JPanel();
        panel.setBounds(550,50,200,160);
        panel.setBackground(Color.PINK);
        c.add(panel);
        
        previewLabel = new JLabel("Preview");
        previewLabel.setBounds(630,200,100,50);
        c.add(previewLabel);
        
        slider1.addChangeListener(this);
        slider2.addChangeListener(this);
        slider3.addChangeListener(this);
    }
 
    @Override
    public void stateChanged(ChangeEvent e) {
        
        int rValue = slider1.getValue();
        int gValue = slider2.getValue();
        int bValue = slider3.getValue();
        
        tf1.setText(""+rValue);
        tf2.setText(""+gValue);
        tf3.setText(""+bValue);
        
        Color color = new Color(rValue,gValue,bValue);
        panel.setBackground(color);
    }
    public static void main(String[] args) {
        Slider frame = new  Slider();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100,100,800,350);
        frame.setTitle("Slider Demo");
    }

 

    
}
