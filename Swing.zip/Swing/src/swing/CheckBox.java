
package swing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JFrame;

public class CheckBox extends JFrame {
    private Container c;
    private JCheckBox javaCheckBox,cCheckBox,mysqlCheckBox;
    private ButtonGroup grp;
    private Font f;
    CheckBox()
    {
        initComponents();
    }
    public void initComponents()
    {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(100,50,500,400);
        this.setTitle("JCheckBox Demo");
        
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.MAGENTA);
        
        f = new Font("Arial",Font.BOLD + Font.ITALIC,18);
        
        grp = new ButtonGroup();
        
        javaCheckBox = new JCheckBox("Java");
        javaCheckBox.setBounds(50,100,100,30);
        javaCheckBox.setBackground(Color.MAGENTA);
        javaCheckBox.setFont(f);
        c.add(javaCheckBox);
        
        cCheckBox = new JCheckBox("C");
        cCheckBox.setBounds(50,130,100,30);
        cCheckBox.setBackground(Color.MAGENTA);
        cCheckBox.setFont(f);
        c.add(cCheckBox);
        
        mysqlCheckBox = new JCheckBox("Mysql",true);
        mysqlCheckBox.setBounds(50,160,100,30);
        mysqlCheckBox.setBackground(Color.MAGENTA);
        mysqlCheckBox.setFont(f);
        c.add(mysqlCheckBox);
        grp.add(javaCheckBox);
        grp.add(cCheckBox);
        grp.add(mysqlCheckBox);
        
    }
    public static void main(String[] args) {
       CheckBox frame = new CheckBox();
        frame.setVisible(true);
    }
}
