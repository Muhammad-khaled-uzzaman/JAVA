
package Example1;

public class Native {
    
    static{
        System.out.println("Native library path");
    }
    public native void m();
}
