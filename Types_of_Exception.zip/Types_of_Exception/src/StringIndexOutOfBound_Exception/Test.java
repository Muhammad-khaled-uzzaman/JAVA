
package StringIndexOutOfBound_Exception;

public class Test {
    
    public static void main(String[] args) {
       try{
            String a = "This is like chipping";
        
        System.out.println(a.charAt(30));
       }catch(StringIndexOutOfBoundsException e){
           System.out.println("StringIndexOutOfBoundsException");
       }
    }
}
