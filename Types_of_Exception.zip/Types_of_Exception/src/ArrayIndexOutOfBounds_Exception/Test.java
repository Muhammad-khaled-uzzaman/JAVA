package ArrayIndexOutOfBounds_Exception;

public class Test {

    public static void main(String[] args) {

        try {
            int[] a = new int[5];

            a[6] = 10;
            System.out.println(a[6]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array Index is Out Of Bounds");
        }
    }
}
