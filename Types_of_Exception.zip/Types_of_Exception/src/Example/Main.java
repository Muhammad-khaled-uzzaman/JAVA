/*
For example, following Java code fails in compilation with error message
“exception Derived has already been caught”
*/
package Example;

public class Main {
    
    public static void main(String[] args) {
        try{
            throw new Derived();
        }
        catch(Base b){
            System.out.println(b);
        }
        /*
        catch(Derived d){
            
        }
*/
    }
}
