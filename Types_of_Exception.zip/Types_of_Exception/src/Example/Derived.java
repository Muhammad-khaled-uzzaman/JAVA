
package Example;

public class Derived extends Base {
    
}
