
package Example;

public class Base extends Exception {
    
}
