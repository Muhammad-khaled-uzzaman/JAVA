
package number_system;

public class Number1 {
    public static void main(String[] args) {
        int decimal = 15;
        
        String binary = Integer.toBinaryString(decimal);
        System.out.println("binary = "+binary);
        
        String octal = Integer.toOctalString(decimal);
        System.out.println("octal= "+octal);
        
        String hex = Integer.toHexString(decimal);
        System.out.println("hexadecimal = "+hex);
        
        
    }
}
