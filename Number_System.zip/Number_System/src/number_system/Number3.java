
package number_system;

public class Number3 {
    public static void main(String[] args) {
        
        String binary = "1010";
        
        int decimal = Integer.parseInt(binary , 2);
        System.out.println("decimal = "+decimal);
        
        String octal = "675";
        
        decimal = Integer.parseInt(octal , 8);
        System.out.println("decimal = "+decimal);
        
        String hex = "F";
        
        decimal = Integer.parseInt(hex , 16);
        System.out.println("decimal = "+decimal);
    }
}
