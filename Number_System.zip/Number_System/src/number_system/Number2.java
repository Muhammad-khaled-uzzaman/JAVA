
package number_system;

import java.util.Scanner;


public class Number2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int decimal;
        
        System.out.println("Enter any decimal number : ");
        decimal = input.nextInt();
        
          
        String hex = Integer.toHexString(decimal);
        System.out.println("hexadecimal = "+hex);
    }
    
}
