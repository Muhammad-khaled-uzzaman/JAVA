package Example9;

public class InvalidMarks extends Exception {

    public InvalidMarks(String string) {
        super(string);
    }
}
