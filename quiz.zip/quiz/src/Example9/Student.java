package Example9;

public class Student implements Information {

    public String name;
    private double marks;

    
    public void setMarks(double Marks) throws InvalidMarks {
        if (Marks < 0) {
            throw new InvalidMarks("Marks can not be negative");
        }

    }

    @Override
    public void show() {
        try {
            System.out.println("Student Name:" + this.name);
            System.out.println("Student marks" + this.marks);
        } catch (ArithmeticException e) {
            System.out.println(e);
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}
