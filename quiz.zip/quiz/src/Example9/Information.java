package Example9;

public interface Information {

    void show();
}
