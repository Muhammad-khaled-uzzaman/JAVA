package Example5;

public class MidTerm {

    public static void main(String[] args) {
        Test test1 = new Test(5, 10);
        System.out.println(test1.num1);
        Test test2 = test1;
        test2.num2 = 25;
        test2.num1 = 12;
        System.out.println(test1.num2);
        Test test3 = test1;
        test1 = null;
        System.out.println(test3.num1);
    }
}
