package Example5;

public class Test {

    public int num1;
    public int num2;

    public Test(int num1, int num2) {
        System.out.println("Constructor of Test is called");
        this.num1 = num1 + 10;
        this.num2 = num2;
    }
}
