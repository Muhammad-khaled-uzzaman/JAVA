package Example15;

public class NoAmicableNumbersException extends Exception {

    public int x;
    public int y;

    public NoAmicableNumbersException(int x,
            int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        return x + " & " + y + " are not amicable";
    }
}
