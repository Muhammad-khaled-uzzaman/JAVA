package Example15;

import java.util.Scanner;

public class Tintin {

    public static int findProperDivisorSum(int x) {
        int sum = 0;
        for (int i = 1; i < x; i++) {
            if (x % i == 0) {
                sum += i;
            }
        }
        return sum;
    }

    public static void areAmicableNumbers(int m,
            int n) throws NoAmicableNumbersException {
        if (findProperDivisorSum(m) == n
                && findProperDivisorSum(n) == m) {
            System.out.println(m + " & " + n + " are amicable");
        } else {
            throw new NoAmicableNumbersException(m, n);
        }
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int m, n;
        while (true) {
            try {
                m = sc.nextInt();
                n = sc.nextInt();
                areAmicableNumbers(m, n);
            } catch (NoAmicableNumbersException ex) {
                System.out.println(ex);
            }
        }
        
    }
}
