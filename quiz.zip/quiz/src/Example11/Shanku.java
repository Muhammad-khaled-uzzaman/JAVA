package Example11;

import java.util.Scanner;

public class Shanku {

    public static void isPrimeNumber(int n) throws NotPrimeNumberexception {
        if (n == 1) {
            throw new NotPrimeNumberexception(n);
        }
        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
                throw new NotPrimeNumberexception(n);
            }
            System.out.println(n + " sent to Aliens");
        }

        
    }
    public static void main(String args[]) {
        int n;
        Scanner sc = new Scanner(System.in);
        while (true) {
            try {
                n = sc.nextInt();
                isPrimeNumber(n);
            } catch (NotPrimeNumberexception ex) {
                System.out.println(ex);
            }
        }
    }
}
