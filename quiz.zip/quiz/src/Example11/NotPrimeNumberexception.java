package Example11;

public class NotPrimeNumberexception extends Exception {

    int n;

    public NotPrimeNumberexception(int n) {
        this.n = n;
    }

    @Override
    public String toString() {
        return this.n + " is not a prime number.";
    }
}
