package Example16;

import java.util.Scanner;

public class Haddoc {

    public static void main(String args[]) {
        try {
            Scanner sc = new Scanner(System.in);
            int X, Y;
            X = sc.nextInt();
            Y = sc.nextInt();
            ProperDivisorSumThread checker1 = new ProperDivisorSumThread(X);
            ProperDivisorSumThread checker2 = new ProperDivisorSumThread(Y);
            Thread thread1 = new Thread(checker1);

            Thread thread2 = new Thread(checker2);
            thread1.start();
            thread2.start();
            thread1.join();
            thread2.join();
            if (checker1.n == checker2.sum
                    && checker2.n == checker1.sum) {
                System.out.println(X + " & " + Y + " are amicable");
            } else {
                System.out.println(X + " & " + Y + " are not amicable");
            }
        } catch (InterruptedException ex) {
            System.out.println(ex);
        }
    }
}
