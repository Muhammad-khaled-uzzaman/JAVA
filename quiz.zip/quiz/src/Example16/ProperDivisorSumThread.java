package Example16;

public class ProperDivisorSumThread implements Runnable {

    public int n;
    public int sum;

    public ProperDivisorSumThread(int n) {
        this.n = n;
        this.sum = 0;
    }

    public void findProperDivisorSum() {
        for (int i = 1; i < this.n; i++) {
            if (this.n % i == 0) {
                this.sum += i;
            }
        }
    }

    @Override
    public void run() {
        findProperDivisorSum();
    }
}
