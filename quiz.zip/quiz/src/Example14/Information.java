package Example14;

public abstract class Information {

    public void print() {
        System.out.println("print function is called");
    }

    abstract void show();
}


