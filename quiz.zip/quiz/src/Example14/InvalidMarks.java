
package Example14;

public class InvalidMarks extends Exception {
    
    public InvalidMarks(String str){
        super(str);
    }
}
