package Example14;

public class Student {

    public String Name;
    private double Marks;

    public void setMarks(double Marks) throws
            InvalidMarks {
        if (Marks < 0) {
            throw new InvalidMarks("Marks can not be negative");
        }
    }

    void show() {
        try {
            System.out.println("Student Name:" + this.Name);

            System.out.println("Student marks: " + this.Marks);

        } catch (ArithmeticException e) {
            System.out.println(e);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}