package Example10;

public class Main {

    public static void main(String[] args) {
        Clock obj = new Clock();
        obj.setAlarm("10:15");
        obj.setTime("10:15");
        
        System.out.println(obj.compareTime());
    }
}
