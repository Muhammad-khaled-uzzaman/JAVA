
package Example10;

public interface Alarm {
    public void setAlarm(String time);
    public String getAlarm();
}
