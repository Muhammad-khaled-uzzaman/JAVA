package Example10;

public class Clock extends Time {

    String Atime;

    @Override
    public void setAlarm(String time) {
        this.Atime = time;
    }

    @Override
    public String getAlarm() {
        return Atime;
    }

    public String compareTime() {
        if (getAlarm() == getTime()) {
            return "Time Over";
        } else {
            return "Not Over";
        }
    }
}
