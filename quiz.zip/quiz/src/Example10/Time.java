package Example10;

public abstract class Time implements Alarm {

    String time;

    public void setTime(String time) {
        this.time = time;
    }

    public String getTime() {
        return time;
    }
}
