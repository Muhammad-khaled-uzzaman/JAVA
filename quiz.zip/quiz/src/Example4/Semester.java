package Example4;

public class Semester extends Student {

    private double semesterNum;

    public Semester() {
    }

    public Semester(double semesterNum) {
        this.semesterNum = semesterNum;
    }

    public Semester(int id, String name) {
        super(id, name);
    }

    public void StudentsInClass(Semester ara[]) {
        System.out.println("Students of semester " + semesterNum + " are: ");
        for (int i = 0; i < ara.length; i++) {
            System.out.println("Student ID = " + ara[i].getSid()
                    + " and Name = " + ara[i].getSname());
        }
    }
}
