package Example4;

public class Main {

    public static void main(String[] args) {
        Semester ara[] = new Semester[3];
        ara[0] = new Semester(1, "A");
        ara[1] = new Semester(2, "B");
        ara[2] = new Semester(3, "C");

        Semester obj = new Semester(1.2);
        obj.StudentsInClass(ara);
    }
}
