package Example2;

public class B extends A {

    private int c;

    public B(int a, int b, int c) {
        super(a, b);
        this.c = c;
    }

    public void showInformation() {
        B obj1 = new B(1, 2, 3);
        System.out.println(obj1.b);
        System.out.println(obj1.c);
    }
}
