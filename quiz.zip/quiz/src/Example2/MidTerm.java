
package Example2;

public class MidTerm {
    
    public static void main(String[] args) {
        C ob = new C(10,20,30,40);
        ob.showInformation();
    }
}
