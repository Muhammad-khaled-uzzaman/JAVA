package Example2;

public class C extends B {

    public int d;

    public C(int a,int b,int c,int d) {
        super(a,b,c);
        this.d = d;
    }
}
