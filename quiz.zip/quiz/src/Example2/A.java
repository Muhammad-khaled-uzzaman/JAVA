package Example2;

public class A {

    public int a;
    public int b;

    public A(int a, int b) {
        this.a = a;
        this.b = b;

    }
}
