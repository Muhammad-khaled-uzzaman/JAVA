package Example1;

public class MidTerm {

    public static void main(String[] args) {
        Test test1 = new Test(20, 2);
        System.out.println(test1.num1);
        test1.num2 = 4;
        Test test2 = test1;
        test2.num2 = 8;
        System.out.println(test1.num2);
        test2.num1 = 10;
        Test test3 = test1;
        test1 = null;
        System.out.println(test3.num1);
        System.out.println(test2.num2);
    }
}
