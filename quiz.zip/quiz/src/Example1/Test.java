package Example1;

public class Test {

    public int num1;
    public int num2;

    public Test(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }
}
