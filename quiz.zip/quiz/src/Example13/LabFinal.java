package Example13;

public class LabFinal {

    public static void main(String[] args) {
        Employee emp = new Employee();
        try {
            try {
                emp.setAge(-2);
            } catch (InvalidAge ia) {
                System.out.println("Age can not be negative");
            }
            String salary = "100K";
            emp.salary = Integer.parseInt(salary);
        } catch (NullPointerException e) {
            System.out.println("NullPointerException is caught");
        } catch (NumberFormatException e) {
            System.out.println("NumberFormatException is caught");
        } catch (Exception e) {
            System.out.println("Exception is caught");
        } finally {
            System.out.println("Good Luck !!");
        }
    }
}
