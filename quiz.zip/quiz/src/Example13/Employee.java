package Example13;

public class Employee {

    public String name;
    public int age;
    public int salary;

    public void setAge(int age) throws InvalidAge {
        if (age < 0) {
            throw new InvalidAge("Age is Invalid");
        }
    }
}
