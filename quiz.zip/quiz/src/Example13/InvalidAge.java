package Example13;

public class InvalidAge extends Exception {

    public InvalidAge(String string) {
        super(string);
    }
}
