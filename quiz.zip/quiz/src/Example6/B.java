package Example6;

public class B extends A {

    public int c;

    public B(int c) {
        super(10);
        this.c = c;
    }

    public B(int a, int c) {
        super(a, 200);
        this.c = c;
    }

    public void showInformation() {
        // obj1 = new B();
        B obj2 = new B(10, 20);
        B obj3 = new B(150);
    }
}
