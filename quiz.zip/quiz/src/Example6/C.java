package Example6;

public class C extends A {

    public C() {
        super(12);
        System.out.println("Class C constructor");
    }
}
