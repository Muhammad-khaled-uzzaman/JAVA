package Example8;

public class Employee {

    public String name;
    public double salary;

    public void setSalary(double salary) throws InvalidSalary {
        if (salary < 0) {
            throw new InvalidSalary("Salary is Invalid");
        }
    }
}
