package Example8;

public class InvalidSalary extends Exception {

    public InvalidSalary(String string) {
        super(string);
    }

}
