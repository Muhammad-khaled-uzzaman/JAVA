package Example8;

public class LabFinale {

    public static void main(String[] args) {
        Employee emp[] = new Employee[1];
        try {
            for (int i = 0; i < 3; i++) {
                emp[i] = new Employee();
                try {
                    emp[i].setSalary(-10.00);
                } catch (InvalidSalary ie) {
                    System.out.println(ie.getMessage());
                    System.out.println("Salary can not be negative ");
                }
            }
        } catch (ArithmeticException e) {
            System.out.println("ArithmeticException is caught");
        } catch (NullPointerException e) {
            System.out.println("NullPointerException is caught");

        } catch (Exception e) {
            System.out.println("Exception is caught");
        } finally {
            System.out.println("Well Done !!");
        }
    }
}
