package Example12;

import java.util.Scanner;

public class ShankuEkaiEksho {

    public static void main(String[] args) {
        int X, Y;
        Scanner sc = new Scanner(System.in);
        X = sc.nextInt();
        Y = sc.nextInt();
        PrimeCheckerThread checker1 = new PrimeCheckerThread(X);
        PrimeCheckerThread checker2 = new PrimeCheckerThread(Y);
        Thread thread1 = new Thread(checker1);
        Thread thread2 = new Thread(checker2);
        thread1.start();
        thread2.start();
        try {
            thread1.join();
            thread2.join();
            if (checker1.isPrime == true
                    && checker2.isPrime == true) {
                System.out.println("Communicationis successfull");
            } else {
                System.out.println("FailedCommunication");

            }
        } catch (InterruptedException ex) {
//Logger.getLogger(ThreadQues.class.getNa
        }
    }
}
