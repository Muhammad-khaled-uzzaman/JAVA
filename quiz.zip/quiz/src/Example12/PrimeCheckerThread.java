package Example12;

public class PrimeCheckerThread implements Runnable {

    public int p;
    public boolean isPrime;

    public PrimeCheckerThread(int p) {
        this.p = p;
        this.isPrime = true;
    }

    public void isPrimeCheck() {
        for (int i = 2; i < this.p; i++) {
            if (this.p % i == 0) {
                this.isPrime = false;
            }
        }
    }

    @Override
    public void run() {
        isPrimeCheck();

    }
}
