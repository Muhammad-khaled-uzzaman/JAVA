
package swingdemo;

import java.awt.Color;
import java.awt.Container;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class AddImageDemo extends JFrame {
    
    private Container c;
     private JLabel ImaLabel;
     private ImageIcon img;
    
    AddImageDemo()
    {
        initComponent();
    }
    
    public void initComponent()
    {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.pink);
        img = new ImageIcon(getClass().getResource("muhammad.jpg"));
          ImaLabel = new JLabel(img);
        ImaLabel.setBounds(10, 20, img.getIconWidth(),img.getIconHeight());
        
        c.add(ImaLabel);
        
    }
    
    public static void main(String[] args) {
        
         AddImageDemo frame = new AddImageDemo();
        
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200,50,800,800);
        frame.setTitle("Label Demo");
        
    }
    
}
