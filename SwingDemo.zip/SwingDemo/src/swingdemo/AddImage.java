
package swingdemo;

import java.awt.Color;
import java.awt.Container;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class AddImage extends JFrame {
     private Container c;
     private JLabel ImaLabel;
     private ImageIcon img;
    
    AddImage()
    {
        initComponent();
    }
    
    public void initComponent()
    {
        
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.pink);
        
        img = new ImageIcon(getClass().getResource("khaled.jpg"));
        
        ImaLabel = new JLabel(img);
        ImaLabel.setBounds(10, 20, img.getIconWidth(),img.getIconHeight());
        
        c.add(ImaLabel);
        
    }
    
    public static void main(String[] args) {
        
         
       AddImage frame = new AddImage();
        
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200,50,800,3000);
        frame.setTitle("Label Demo");
        
        
    }
    
}
