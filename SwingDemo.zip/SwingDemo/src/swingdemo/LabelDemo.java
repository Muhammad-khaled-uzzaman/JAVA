
package swingdemo;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class LabelDemo extends JFrame {
    
    private Container c;
    private JLabel userLabel,passLabel;
    LabelDemo()
    {
        initComponent();
    }
    
    private void initComponent()
    {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.pink);
        
        userLabel = new JLabel();
        userLabel.setText("Enter your name :");
        userLabel.setBounds(50,20,150,50);
        c.add(userLabel);
        
        passLabel = new JLabel("Enter your password :");
        passLabel.setBounds(50, 80, 150, 50);
        c.add(passLabel);
        
    }
    public static void main(String[] args) {
        
        LabelDemo frame = new LabelDemo();
        
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200,50,500,400);
        frame.setTitle("Label Demo");
        
    }
    
}
