
package swingdemo;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ForeGround extends JFrame {
     private Container c;
    private JLabel userLabel,passLabel;
    private Font f;
    
    ForeGround ()
    {
        initComponent();
    }
    public void initComponent()
    {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.pink);
        
        f = new Font("Arial",Font.BOLD,14);
        
        userLabel = new JLabel();
        userLabel.setText("Enter your name :");
        userLabel.setBounds(50,20,150,50);
        userLabel.setFont(f);
        userLabel.setForeground(Color.RED);
        userLabel.setOpaque(true);
        userLabel.setBackground(Color.yellow);
        c.add(userLabel);
        
        passLabel = new JLabel("Enter your password :");
        passLabel.setBounds(50, 80, 200, 50);
        passLabel.setFont(f);
        c.add(passLabel);
    }
    
    
    public static void main(String[] args) {
         
       ForeGround  frame = new ForeGround ();
        
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200,50,500,400);
        frame.setTitle("Label Demo");
        
    }
    
}
