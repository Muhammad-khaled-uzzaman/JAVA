package project;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Project extends JFrame {

    private Container c;
    private JPasswordField pf;
    private JLabel ImaLabel;
    private ImageIcon img;
    private Font f;
    private JTextArea ta;
    private JScrollPane scroll;
    private JButton loginbutton, clearbutton;

    Project() {
        initComponents();
    }

    public void initComponents() {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.white);
        f = new Font("Arial", Font.ITALIC, 25);
        img = new ImageIcon(getClass().getResource("m.png"));
        ImaLabel = new JLabel(img);
        ImaLabel.setBounds(10, 20, img.getIconWidth(), img.getIconHeight());

        c.add(ImaLabel);

        pf = new JPasswordField();
        pf.setEchoChar('*');
        pf.setFont(f);
        pf.setBounds(330, 370, 230, 30);
        c.add(pf);

        ta = new JTextArea();
        ta.setBounds(330, 320, 230, 30);
        ta.setForeground(Color.BLACK);
        ta.setBackground(Color.white);
        ta.setFont(f);
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        c.add(ta);

        loginbutton = new JButton("Login");
        loginbutton.setBounds(320, 420, 70, 30);
        loginbutton.setForeground(Color.BLUE);
        ImaLabel.add(loginbutton);

        clearbutton = new JButton("Clear");
        clearbutton.setBounds(475, 420, 70, 30);
        clearbutton.setForeground(Color.BLUE);
        ImaLabel.add(clearbutton);

        loginbutton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                String userName = ta.getText();
                String password = pf.getText();

                if (userName.equals("khaled") && password.equals("12345")) {
                    JOptionPane.showMessageDialog(null, " You are successfully login, userName");
                    NewFrame frame = new NewFrame();
                    frame.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, " Invalid userName or password");
                }

            }
        });

        clearbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                ta.setText("");
                pf.setText("");

            }
        });

    }

    public static void main(String[] args) {
        Project frame = new Project();

        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200, 50, 702, 679);
        frame.setResizable(false);
        frame.setTitle("");
    }

}
