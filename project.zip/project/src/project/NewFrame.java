package project;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class NewFrame extends JFrame {

    private Container c;
    private JLabel label;

    NewFrame() {
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setBounds(500, 50, 702, 679);
        this.setTitle("New Frame");
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.white);
    }

    public static void main(String[] args) {

        NewFrame fr = new NewFrame();
        fr.setVisible(true);
        fr.setResizable(false);
    }

}
