
package Example_3;

public class Test {
    
    public static void main(String[] args) {
        //Thread.sleep(10000);
        System.out.println("Hello Geeks");
    }
}
