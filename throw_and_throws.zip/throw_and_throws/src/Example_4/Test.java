package Example_4;

public class Test {

    public static void main(String[] args) throws InterruptedException {

        Thread.sleep(10000);
        System.out.println("Hello Geeks");
    }
}
