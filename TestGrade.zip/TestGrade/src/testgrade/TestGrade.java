package testgrade;

public class TestGrade {

    public static void main(String[] args) {
        Grade obj1 = new Grade("Java", "1206", 66);
        Grade obj2 = new Grade("C", "1105", 80);

        System.out.println(obj1.checkGrade(obj1.getMarks()));

        if (obj1.compareGrades(obj2) == true) {
            System.out.println("Same");
        } else {
            System.out.println("Different");
        }
    }
}
