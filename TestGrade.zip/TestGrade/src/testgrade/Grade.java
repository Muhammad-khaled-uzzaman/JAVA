package testgrade;

public class Grade {

    private String courseName;
    private String courseNumber;
    private double marks;

    public Grade() {
        courseName = null;
        courseNumber = null;
        marks = -1;

    }

    public Grade(String courseName, String courseNumber, double marks) {
        this.courseName = courseName;
        this.courseNumber = courseNumber;
        this.marks = marks;

    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseNumber() {
        return courseNumber;
    }

    public void setCourseNumber(String courseNumber) {
        this.courseNumber = courseNumber;
    }

    public double getMarks() {
        return marks;
    }

    public void setMarks(double marks) {
        this.marks = marks;
    }
    
    public String checkGrade(double Marks){
        String grade="";
        if (Marks>=80&&Marks<=100) {
            grade = "A";
        }
        else if(Marks >= 70 && Marks < 80)
        {
            grade = "B";
        }
        else if(Marks >= 50 && Marks < 70)
        {
            grade = "C";
        }
        else if(Marks >= 40 && Marks < 50)
        {
            grade = "D";
        }
        else if(Marks >= 0 && Marks < 40)      
        {
            grade = "F";
        }
        
        return grade;
    }
    
    public boolean compareGrades(Grade obj){
        
        boolean res=false;
        if(checkGrade(this.marks) == checkGrade(obj.marks)){
            res=true;
        }  
            
        return res;
    }

}
