/*
How to swap or exchange objects in Java?

/ A Java program to demonstrate that we can swap two 
// objects be swapping members. 
 */
package swapDemo1;

public class Car {

    int no;

    Car(int no) {
        this.no = no;
    }
}
