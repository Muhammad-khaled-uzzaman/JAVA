package swapDemo2;

public class Main {
        // swap() doesn't swap c1 and c2
    public static void swap(Car c1, Car c2) {
        Car temp = c1;
        c1 = c2;
        c2 = temp;
    }
    public static void main(String[] args) {
        Car c1 = new Car(101,1);
        Car c2 = new Car(102,2);
        swap(c1,c2);
        c1.print();
        c2.print();
    }
}
