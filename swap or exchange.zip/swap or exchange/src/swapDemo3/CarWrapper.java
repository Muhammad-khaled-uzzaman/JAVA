package swapDemo3;
// A Wrapper over class that is used for swapping 

public class CarWrapper {

    Car c;

    CarWrapper(Car c) {
        this.c = c;
    }
}
