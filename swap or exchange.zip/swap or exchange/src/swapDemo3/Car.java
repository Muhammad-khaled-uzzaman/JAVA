/*
// A Java program to demonstrate that we can use wrapper 
// classes to swap to objects 
  
// A car with model and no.
*/
package swapDemo3;

public class Car {

    int model, no;

    Car(int model, int no) {
        this.model = model;
        this.no = no;
    }

    void print() {
        System.out.println("no = " + no + ",model =" + model);
    }
}
