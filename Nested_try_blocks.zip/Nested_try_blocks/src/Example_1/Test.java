package Example_1;

public class Test {

    public static void main(String[] args) {

        try {
            int arr[] = {1, 2, 3, 4, 5};

            System.out.println(arr[5]);

            try {

                int x = arr[2] / 0;
            } catch (ArithmeticException e) {
                System.out.println("division by zero is not possible");
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException");
            System.out.println("Element at such index does not exists");
        }
    }
}
